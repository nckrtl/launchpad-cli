import Toolbar from './Toolbar'

const NckRtl = {
    Toolbar: Object.assign(Toolbar, Toolbar),
}

export default NckRtl