import Controllers from './Controllers'

const Toolbar = {
    Controllers: Object.assign(Controllers, Controllers),
}

export default Toolbar