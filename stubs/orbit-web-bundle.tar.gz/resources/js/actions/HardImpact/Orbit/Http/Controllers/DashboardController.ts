import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\DashboardController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DashboardController.php:10
* @route '/'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DashboardController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DashboardController.php:10
* @route '/'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DashboardController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DashboardController.php:10
* @route '/'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DashboardController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DashboardController.php:10
* @route '/'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

const DashboardController = { index }

export default DashboardController