import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
const indexd582b87fffb099584ead7c52ce664aff = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexd582b87fffb099584ead7c52ce664aff.url(options),
    method: 'get',
})

indexd582b87fffb099584ead7c52ce664aff.definition = {
    methods: ["get","head"],
    url: '/dns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
indexd582b87fffb099584ead7c52ce664aff.url = (options?: RouteQueryOptions) => {
    return indexd582b87fffb099584ead7c52ce664aff.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
indexd582b87fffb099584ead7c52ce664aff.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexd582b87fffb099584ead7c52ce664aff.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
indexd582b87fffb099584ead7c52ce664aff.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexd582b87fffb099584ead7c52ce664aff.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
const index8673e7a3d6c2dc85641136d1972adb31 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index8673e7a3d6c2dc85641136d1972adb31.url(args, options),
    method: 'get',
})

index8673e7a3d6c2dc85641136d1972adb31.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/dns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
index8673e7a3d6c2dc85641136d1972adb31.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return index8673e7a3d6c2dc85641136d1972adb31.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
index8673e7a3d6c2dc85641136d1972adb31.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index8673e7a3d6c2dc85641136d1972adb31.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
index8673e7a3d6c2dc85641136d1972adb31.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index8673e7a3d6c2dc85641136d1972adb31.url(args, options),
    method: 'head',
})

export const index = {
    '/dns': indexd582b87fffb099584ead7c52ce664aff,
    '/environments/{environment}/dns': index8673e7a3d6c2dc85641136d1972adb31,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/dns'
*/
const updated582b87fffb099584ead7c52ce664aff = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updated582b87fffb099584ead7c52ce664aff.url(options),
    method: 'post',
})

updated582b87fffb099584ead7c52ce664aff.definition = {
    methods: ["post"],
    url: '/dns',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/dns'
*/
updated582b87fffb099584ead7c52ce664aff.url = (options?: RouteQueryOptions) => {
    return updated582b87fffb099584ead7c52ce664aff.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/dns'
*/
updated582b87fffb099584ead7c52ce664aff.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updated582b87fffb099584ead7c52ce664aff.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/environments/{environment}/dns'
*/
const update8673e7a3d6c2dc85641136d1972adb31 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update8673e7a3d6c2dc85641136d1972adb31.url(args, options),
    method: 'post',
})

update8673e7a3d6c2dc85641136d1972adb31.definition = {
    methods: ["post"],
    url: '/environments/{environment}/dns',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/environments/{environment}/dns'
*/
update8673e7a3d6c2dc85641136d1972adb31.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return update8673e7a3d6c2dc85641136d1972adb31.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/environments/{environment}/dns'
*/
update8673e7a3d6c2dc85641136d1972adb31.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update8673e7a3d6c2dc85641136d1972adb31.url(args, options),
    method: 'post',
})

export const update = {
    '/dns': updated582b87fffb099584ead7c52ce664aff,
    '/environments/{environment}/dns': update8673e7a3d6c2dc85641136d1972adb31,
}

const DnsController = { index, update }

export default DnsController