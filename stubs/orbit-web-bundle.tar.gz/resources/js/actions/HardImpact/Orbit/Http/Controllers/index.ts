import DashboardController from './DashboardController'
import EnvironmentController from './EnvironmentController'
import SettingsController from './SettingsController'
import DnsController from './DnsController'
import ProvisioningController from './ProvisioningController'
import JobController from './JobController'

const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
    EnvironmentController: Object.assign(EnvironmentController, EnvironmentController),
    SettingsController: Object.assign(SettingsController, SettingsController),
    DnsController: Object.assign(DnsController, DnsController),
    ProvisioningController: Object.assign(ProvisioningController, ProvisioningController),
    JobController: Object.assign(JobController, JobController),
}

export default Controllers