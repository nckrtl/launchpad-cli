import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\JobController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/JobController.php:13
* @route '/api/jobs/{trackedJob}'
*/
export const show = (args: { trackedJob: string | number | { id: string | number } } | [trackedJob: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/jobs/{trackedJob}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\JobController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/JobController.php:13
* @route '/api/jobs/{trackedJob}'
*/
show.url = (args: { trackedJob: string | number | { id: string | number } } | [trackedJob: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { trackedJob: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { trackedJob: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            trackedJob: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        trackedJob: typeof args.trackedJob === 'object'
        ? args.trackedJob.id
        : args.trackedJob,
    }

    return show.definition.url
            .replace('{trackedJob}', parsedArgs.trackedJob.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\JobController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/JobController.php:13
* @route '/api/jobs/{trackedJob}'
*/
show.get = (args: { trackedJob: string | number | { id: string | number } } | [trackedJob: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\JobController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/JobController.php:13
* @route '/api/jobs/{trackedJob}'
*/
show.head = (args: { trackedJob: string | number | { id: string | number } } | [trackedJob: string | number | { id: string | number } ] | string | number | { id: string | number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

const JobController = { show }

export default JobController