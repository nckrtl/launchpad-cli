import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults, validateParameters } from './../../../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/set-default'
*/
const setDefault81ab650d4e6754d74b2679ab32afa36d = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefault81ab650d4e6754d74b2679ab32afa36d.url(options),
    method: 'post',
})

setDefault81ab650d4e6754d74b2679ab32afa36d.definition = {
    methods: ["post"],
    url: '/set-default',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/set-default'
*/
setDefault81ab650d4e6754d74b2679ab32afa36d.url = (options?: RouteQueryOptions) => {
    return setDefault81ab650d4e6754d74b2679ab32afa36d.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/set-default'
*/
setDefault81ab650d4e6754d74b2679ab32afa36d.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefault81ab650d4e6754d74b2679ab32afa36d.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/environments/{environment}/set-default'
*/
const setDefaultcbe8c12e758ed5ac135915b35efaa070 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefaultcbe8c12e758ed5ac135915b35efaa070.url(args, options),
    method: 'post',
})

setDefaultcbe8c12e758ed5ac135915b35efaa070.definition = {
    methods: ["post"],
    url: '/environments/{environment}/set-default',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/environments/{environment}/set-default'
*/
setDefaultcbe8c12e758ed5ac135915b35efaa070.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return setDefaultcbe8c12e758ed5ac135915b35efaa070.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/environments/{environment}/set-default'
*/
setDefaultcbe8c12e758ed5ac135915b35efaa070.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefaultcbe8c12e758ed5ac135915b35efaa070.url(args, options),
    method: 'post',
})

export const setDefault = {
    '/set-default': setDefault81ab650d4e6754d74b2679ab32afa36d,
    '/environments/{environment}/set-default': setDefaultcbe8c12e758ed5ac135915b35efaa070,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
const runDoctor798712935d7b910d6cc55c0c2edcf7e4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runDoctor798712935d7b910d6cc55c0c2edcf7e4.url(options),
    method: 'get',
})

runDoctor798712935d7b910d6cc55c0c2edcf7e4.definition = {
    methods: ["get","head"],
    url: '/doctor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
runDoctor798712935d7b910d6cc55c0c2edcf7e4.url = (options?: RouteQueryOptions) => {
    return runDoctor798712935d7b910d6cc55c0c2edcf7e4.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
runDoctor798712935d7b910d6cc55c0c2edcf7e4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runDoctor798712935d7b910d6cc55c0c2edcf7e4.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
runDoctor798712935d7b910d6cc55c0c2edcf7e4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: runDoctor798712935d7b910d6cc55c0c2edcf7e4.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
const runDoctor339e9c91ee18a9185fdae1455d4d5a07 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runDoctor339e9c91ee18a9185fdae1455d4d5a07.url(args, options),
    method: 'get',
})

runDoctor339e9c91ee18a9185fdae1455d4d5a07.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/doctor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
runDoctor339e9c91ee18a9185fdae1455d4d5a07.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return runDoctor339e9c91ee18a9185fdae1455d4d5a07.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
runDoctor339e9c91ee18a9185fdae1455d4d5a07.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: runDoctor339e9c91ee18a9185fdae1455d4d5a07.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::runDoctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
runDoctor339e9c91ee18a9185fdae1455d4d5a07.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: runDoctor339e9c91ee18a9185fdae1455d4d5a07.url(args, options),
    method: 'head',
})

export const runDoctor = {
    '/doctor': runDoctor798712935d7b910d6cc55c0c2edcf7e4,
    '/environments/{environment}/doctor': runDoctor339e9c91ee18a9185fdae1455d4d5a07,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
const quickCheckb8fe881d78a37f5ae5c0c3d80e701802 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickCheckb8fe881d78a37f5ae5c0c3d80e701802.url(options),
    method: 'get',
})

quickCheckb8fe881d78a37f5ae5c0c3d80e701802.definition = {
    methods: ["get","head"],
    url: '/doctor/quick',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
quickCheckb8fe881d78a37f5ae5c0c3d80e701802.url = (options?: RouteQueryOptions) => {
    return quickCheckb8fe881d78a37f5ae5c0c3d80e701802.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
quickCheckb8fe881d78a37f5ae5c0c3d80e701802.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickCheckb8fe881d78a37f5ae5c0c3d80e701802.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
quickCheckb8fe881d78a37f5ae5c0c3d80e701802.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quickCheckb8fe881d78a37f5ae5c0c3d80e701802.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
const quickChecked6db0ef389727f4ae119a967423d589 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickChecked6db0ef389727f4ae119a967423d589.url(args, options),
    method: 'get',
})

quickChecked6db0ef389727f4ae119a967423d589.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/doctor/quick',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
quickChecked6db0ef389727f4ae119a967423d589.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return quickChecked6db0ef389727f4ae119a967423d589.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
quickChecked6db0ef389727f4ae119a967423d589.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quickChecked6db0ef389727f4ae119a967423d589.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quickCheck
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
quickChecked6db0ef389727f4ae119a967423d589.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quickChecked6db0ef389727f4ae119a967423d589.url(args, options),
    method: 'head',
})

export const quickCheck = {
    '/doctor/quick': quickCheckb8fe881d78a37f5ae5c0c3d80e701802,
    '/environments/{environment}/doctor/quick': quickChecked6db0ef389727f4ae119a967423d589,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fixDoctorIssue
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/doctor/fix/{check}'
*/
const fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91 = (args: { check: string | number } | [check: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91.url(args, options),
    method: 'post',
})

fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91.definition = {
    methods: ["post"],
    url: '/doctor/fix/{check}',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fixDoctorIssue
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/doctor/fix/{check}'
*/
fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91.url = (args: { check: string | number } | [check: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { check: args }
    }

    if (Array.isArray(args)) {
        args = {
            check: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        check: args.check,
    }

    return fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91.definition.url
            .replace('{check}', parsedArgs.check.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fixDoctorIssue
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/doctor/fix/{check}'
*/
fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91.post = (args: { check: string | number } | [check: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fixDoctorIssue
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/environments/{environment}/doctor/fix/{check}'
*/
const fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1 = (args: { environment: number | { id: number }, check: string | number } | [environment: number | { id: number }, check: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1.url(args, options),
    method: 'post',
})

fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1.definition = {
    methods: ["post"],
    url: '/environments/{environment}/doctor/fix/{check}',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fixDoctorIssue
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/environments/{environment}/doctor/fix/{check}'
*/
fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1.url = (args: { environment: number | { id: number }, check: string | number } | [environment: number | { id: number }, check: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            check: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        check: args.check,
    }

    return fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{check}', parsedArgs.check.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fixDoctorIssue
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/environments/{environment}/doctor/fix/{check}'
*/
fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1.post = (args: { environment: number | { id: number }, check: string | number } | [environment: number | { id: number }, check: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1.url(args, options),
    method: 'post',
})

export const fixDoctorIssue = {
    '/doctor/fix/{check}': fixDoctorIssueec6b6b0321555f33c2fad9ddda18af91,
    '/environments/{environment}/doctor/fix/{check}': fixDoctorIssuebf096fbeee53f0b2b9807a056dca0ed1,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
const sitesPagec5d66bd5c00172bfad72bf3878ac554b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPagec5d66bd5c00172bfad72bf3878ac554b.url(options),
    method: 'get',
})

sitesPagec5d66bd5c00172bfad72bf3878ac554b.definition = {
    methods: ["get","head"],
    url: '/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
sitesPagec5d66bd5c00172bfad72bf3878ac554b.url = (options?: RouteQueryOptions) => {
    return sitesPagec5d66bd5c00172bfad72bf3878ac554b.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
sitesPagec5d66bd5c00172bfad72bf3878ac554b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPagec5d66bd5c00172bfad72bf3878ac554b.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
sitesPagec5d66bd5c00172bfad72bf3878ac554b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesPagec5d66bd5c00172bfad72bf3878ac554b.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
const sitesPage8f35706c95c06c991312479b995e49d2 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPage8f35706c95c06c991312479b995e49d2.url(options),
    method: 'get',
})

sitesPage8f35706c95c06c991312479b995e49d2.definition = {
    methods: ["get","head"],
    url: '/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
sitesPage8f35706c95c06c991312479b995e49d2.url = (options?: RouteQueryOptions) => {
    return sitesPage8f35706c95c06c991312479b995e49d2.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
sitesPage8f35706c95c06c991312479b995e49d2.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPage8f35706c95c06c991312479b995e49d2.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
sitesPage8f35706c95c06c991312479b995e49d2.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesPage8f35706c95c06c991312479b995e49d2.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
const sitesPagef1ae4f46fef3e725ed467b77218a7088 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPagef1ae4f46fef3e725ed467b77218a7088.url(args, options),
    method: 'get',
})

sitesPagef1ae4f46fef3e725ed467b77218a7088.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
sitesPagef1ae4f46fef3e725ed467b77218a7088.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return sitesPagef1ae4f46fef3e725ed467b77218a7088.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
sitesPagef1ae4f46fef3e725ed467b77218a7088.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPagef1ae4f46fef3e725ed467b77218a7088.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
sitesPagef1ae4f46fef3e725ed467b77218a7088.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesPagef1ae4f46fef3e725ed467b77218a7088.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
const sitesPage13193bc4e7973307ae298f994b1e6878 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPage13193bc4e7973307ae298f994b1e6878.url(args, options),
    method: 'get',
})

sitesPage13193bc4e7973307ae298f994b1e6878.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
sitesPage13193bc4e7973307ae298f994b1e6878.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return sitesPage13193bc4e7973307ae298f994b1e6878.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
sitesPage13193bc4e7973307ae298f994b1e6878.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesPage13193bc4e7973307ae298f994b1e6878.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
sitesPage13193bc4e7973307ae298f994b1e6878.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesPage13193bc4e7973307ae298f994b1e6878.url(args, options),
    method: 'head',
})

export const sitesPage = {
    '/sites': sitesPagec5d66bd5c00172bfad72bf3878ac554b,
    '/projects': sitesPage8f35706c95c06c991312479b995e49d2,
    '/environments/{environment}/sites': sitesPagef1ae4f46fef3e725ed467b77218a7088,
    '/environments/{environment}/projects': sitesPage13193bc4e7973307ae298f994b1e6878,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
const servicesPagebbee0fd5659320176905772cd001770a = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: servicesPagebbee0fd5659320176905772cd001770a.url(options),
    method: 'get',
})

servicesPagebbee0fd5659320176905772cd001770a.definition = {
    methods: ["get","head"],
    url: '/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
servicesPagebbee0fd5659320176905772cd001770a.url = (options?: RouteQueryOptions) => {
    return servicesPagebbee0fd5659320176905772cd001770a.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
servicesPagebbee0fd5659320176905772cd001770a.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: servicesPagebbee0fd5659320176905772cd001770a.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
servicesPagebbee0fd5659320176905772cd001770a.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: servicesPagebbee0fd5659320176905772cd001770a.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
const servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.url(args, options),
    method: 'get',
})

servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::servicesPage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d.url(args, options),
    method: 'head',
})

export const servicesPage = {
    '/services': servicesPagebbee0fd5659320176905772cd001770a,
    '/environments/{environment}/services': servicesPage64ab2cf1f0fd18727f1a1a7ea26d321d,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
const orchestratorba071099e6bdb2fef943e7744afe59c7 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorba071099e6bdb2fef943e7744afe59c7.url(options),
    method: 'get',
})

orchestratorba071099e6bdb2fef943e7744afe59c7.definition = {
    methods: ["get","head"],
    url: '/orchestrator',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
orchestratorba071099e6bdb2fef943e7744afe59c7.url = (options?: RouteQueryOptions) => {
    return orchestratorba071099e6bdb2fef943e7744afe59c7.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
orchestratorba071099e6bdb2fef943e7744afe59c7.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorba071099e6bdb2fef943e7744afe59c7.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
orchestratorba071099e6bdb2fef943e7744afe59c7.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorba071099e6bdb2fef943e7744afe59c7.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
const orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.url(args, options),
    method: 'get',
})

orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070.url(args, options),
    method: 'head',
})

export const orchestrator = {
    '/orchestrator': orchestratorba071099e6bdb2fef943e7744afe59c7,
    '/environments/{environment}/orchestrator': orchestratorfd3a150e2f0c2e2472e8b4cd4b0de070,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/orchestrator/enable'
*/
const enableOrchestrator5a73718e480b7ef054ffadc7426f1292 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableOrchestrator5a73718e480b7ef054ffadc7426f1292.url(options),
    method: 'post',
})

enableOrchestrator5a73718e480b7ef054ffadc7426f1292.definition = {
    methods: ["post"],
    url: '/orchestrator/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/orchestrator/enable'
*/
enableOrchestrator5a73718e480b7ef054ffadc7426f1292.url = (options?: RouteQueryOptions) => {
    return enableOrchestrator5a73718e480b7ef054ffadc7426f1292.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/orchestrator/enable'
*/
enableOrchestrator5a73718e480b7ef054ffadc7426f1292.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableOrchestrator5a73718e480b7ef054ffadc7426f1292.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/environments/{environment}/orchestrator/enable'
*/
const enableOrchestratore460bec57cc09a3bd688cc98f4ebe500 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableOrchestratore460bec57cc09a3bd688cc98f4ebe500.url(args, options),
    method: 'post',
})

enableOrchestratore460bec57cc09a3bd688cc98f4ebe500.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/environments/{environment}/orchestrator/enable'
*/
enableOrchestratore460bec57cc09a3bd688cc98f4ebe500.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return enableOrchestratore460bec57cc09a3bd688cc98f4ebe500.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/environments/{environment}/orchestrator/enable'
*/
enableOrchestratore460bec57cc09a3bd688cc98f4ebe500.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableOrchestratore460bec57cc09a3bd688cc98f4ebe500.url(args, options),
    method: 'post',
})

export const enableOrchestrator = {
    '/orchestrator/enable': enableOrchestrator5a73718e480b7ef054ffadc7426f1292,
    '/environments/{environment}/orchestrator/enable': enableOrchestratore460bec57cc09a3bd688cc98f4ebe500,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/orchestrator/disable'
*/
const disableOrchestratore03fd330dcf117318d44a44f938e0a1a = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disableOrchestratore03fd330dcf117318d44a44f938e0a1a.url(options),
    method: 'post',
})

disableOrchestratore03fd330dcf117318d44a44f938e0a1a.definition = {
    methods: ["post"],
    url: '/orchestrator/disable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/orchestrator/disable'
*/
disableOrchestratore03fd330dcf117318d44a44f938e0a1a.url = (options?: RouteQueryOptions) => {
    return disableOrchestratore03fd330dcf117318d44a44f938e0a1a.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/orchestrator/disable'
*/
disableOrchestratore03fd330dcf117318d44a44f938e0a1a.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disableOrchestratore03fd330dcf117318d44a44f938e0a1a.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/environments/{environment}/orchestrator/disable'
*/
const disableOrchestrator4ad621954dcc4085310a0b977238995f = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disableOrchestrator4ad621954dcc4085310a0b977238995f.url(args, options),
    method: 'post',
})

disableOrchestrator4ad621954dcc4085310a0b977238995f.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/disable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/environments/{environment}/orchestrator/disable'
*/
disableOrchestrator4ad621954dcc4085310a0b977238995f.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return disableOrchestrator4ad621954dcc4085310a0b977238995f.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/environments/{environment}/orchestrator/disable'
*/
disableOrchestrator4ad621954dcc4085310a0b977238995f.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disableOrchestrator4ad621954dcc4085310a0b977238995f.url(args, options),
    method: 'post',
})

export const disableOrchestrator = {
    '/orchestrator/disable': disableOrchestratore03fd330dcf117318d44a44f938e0a1a,
    '/environments/{environment}/orchestrator/disable': disableOrchestrator4ad621954dcc4085310a0b977238995f,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::installOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/orchestrator/install'
*/
const installOrchestrator089f1f9e7198d9e702335617eb9e9c89 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: installOrchestrator089f1f9e7198d9e702335617eb9e9c89.url(options),
    method: 'post',
})

installOrchestrator089f1f9e7198d9e702335617eb9e9c89.definition = {
    methods: ["post"],
    url: '/orchestrator/install',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::installOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/orchestrator/install'
*/
installOrchestrator089f1f9e7198d9e702335617eb9e9c89.url = (options?: RouteQueryOptions) => {
    return installOrchestrator089f1f9e7198d9e702335617eb9e9c89.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::installOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/orchestrator/install'
*/
installOrchestrator089f1f9e7198d9e702335617eb9e9c89.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: installOrchestrator089f1f9e7198d9e702335617eb9e9c89.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::installOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/environments/{environment}/orchestrator/install'
*/
const installOrchestratorb09ca126552102a8b393d97adb322c02 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: installOrchestratorb09ca126552102a8b393d97adb322c02.url(args, options),
    method: 'post',
})

installOrchestratorb09ca126552102a8b393d97adb322c02.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/install',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::installOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/environments/{environment}/orchestrator/install'
*/
installOrchestratorb09ca126552102a8b393d97adb322c02.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return installOrchestratorb09ca126552102a8b393d97adb322c02.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::installOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/environments/{environment}/orchestrator/install'
*/
installOrchestratorb09ca126552102a8b393d97adb322c02.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: installOrchestratorb09ca126552102a8b393d97adb322c02.url(args, options),
    method: 'post',
})

export const installOrchestrator = {
    '/orchestrator/install': installOrchestrator089f1f9e7198d9e702335617eb9e9c89,
    '/environments/{environment}/orchestrator/install': installOrchestratorb09ca126552102a8b393d97adb322c02,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
const detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.url(options),
    method: 'get',
})

detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.definition = {
    methods: ["get","head"],
    url: '/orchestrator/detect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.url = (options?: RouteQueryOptions) => {
    return detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
const detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.url(args, options),
    method: 'get',
})

detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/detect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detectOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075.url(args, options),
    method: 'head',
})

export const detectOrchestrator = {
    '/orchestrator/detect': detectOrchestratorbec2165d5f14cb9e5cf77f2c8a01a3b6,
    '/environments/{environment}/orchestrator/detect': detectOrchestrator9a854b2b8a4be8d83bf7fcd2dabb8075,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcileOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/orchestrator/reconcile'
*/
const reconcileOrchestrator141c8692d881731e2cda6cd0286f192e = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcileOrchestrator141c8692d881731e2cda6cd0286f192e.url(options),
    method: 'post',
})

reconcileOrchestrator141c8692d881731e2cda6cd0286f192e.definition = {
    methods: ["post"],
    url: '/orchestrator/reconcile',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcileOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/orchestrator/reconcile'
*/
reconcileOrchestrator141c8692d881731e2cda6cd0286f192e.url = (options?: RouteQueryOptions) => {
    return reconcileOrchestrator141c8692d881731e2cda6cd0286f192e.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcileOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/orchestrator/reconcile'
*/
reconcileOrchestrator141c8692d881731e2cda6cd0286f192e.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcileOrchestrator141c8692d881731e2cda6cd0286f192e.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcileOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/environments/{environment}/orchestrator/reconcile'
*/
const reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4.url(args, options),
    method: 'post',
})

reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/reconcile',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcileOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/environments/{environment}/orchestrator/reconcile'
*/
reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcileOrchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/environments/{environment}/orchestrator/reconcile'
*/
reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4.url(args, options),
    method: 'post',
})

export const reconcileOrchestrator = {
    '/orchestrator/reconcile': reconcileOrchestrator141c8692d881731e2cda6cd0286f192e,
    '/environments/{environment}/orchestrator/reconcile': reconcileOrchestrator0ead12c9b0ae1212c402155b7b36eed4,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
const orchestratorServices833385249965820c6b14d4cebe3632c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorServices833385249965820c6b14d4cebe3632c9.url(options),
    method: 'get',
})

orchestratorServices833385249965820c6b14d4cebe3632c9.definition = {
    methods: ["get","head"],
    url: '/orchestrator/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
orchestratorServices833385249965820c6b14d4cebe3632c9.url = (options?: RouteQueryOptions) => {
    return orchestratorServices833385249965820c6b14d4cebe3632c9.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
orchestratorServices833385249965820c6b14d4cebe3632c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorServices833385249965820c6b14d4cebe3632c9.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
orchestratorServices833385249965820c6b14d4cebe3632c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorServices833385249965820c6b14d4cebe3632c9.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
const orchestratorServicese8086109a7c3b89d76681a166e181e10 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorServicese8086109a7c3b89d76681a166e181e10.url(args, options),
    method: 'get',
})

orchestratorServicese8086109a7c3b89d76681a166e181e10.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
orchestratorServicese8086109a7c3b89d76681a166e181e10.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return orchestratorServicese8086109a7c3b89d76681a166e181e10.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
orchestratorServicese8086109a7c3b89d76681a166e181e10.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorServicese8086109a7c3b89d76681a166e181e10.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
orchestratorServicese8086109a7c3b89d76681a166e181e10.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorServicese8086109a7c3b89d76681a166e181e10.url(args, options),
    method: 'head',
})

export const orchestratorServices = {
    '/orchestrator/services': orchestratorServices833385249965820c6b14d4cebe3632c9,
    '/environments/{environment}/orchestrator/services': orchestratorServicese8086109a7c3b89d76681a166e181e10,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
const orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.url(options),
    method: 'get',
})

orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.definition = {
    methods: ["get","head"],
    url: '/orchestrator/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.url = (options?: RouteQueryOptions) => {
    return orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
const orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.url(options),
    method: 'get',
})

orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.definition = {
    methods: ["get","head"],
    url: '/orchestrator/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.url = (options?: RouteQueryOptions) => {
    return orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
const orchestratorSites336d1c786e70c7f75e54be367b75f56a = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSites336d1c786e70c7f75e54be367b75f56a.url(args, options),
    method: 'get',
})

orchestratorSites336d1c786e70c7f75e54be367b75f56a.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
orchestratorSites336d1c786e70c7f75e54be367b75f56a.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return orchestratorSites336d1c786e70c7f75e54be367b75f56a.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
orchestratorSites336d1c786e70c7f75e54be367b75f56a.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSites336d1c786e70c7f75e54be367b75f56a.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
orchestratorSites336d1c786e70c7f75e54be367b75f56a.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorSites336d1c786e70c7f75e54be367b75f56a.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
const orchestratorSites12261deddd7964dd395b3d073042d0f4 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSites12261deddd7964dd395b3d073042d0f4.url(args, options),
    method: 'get',
})

orchestratorSites12261deddd7964dd395b3d073042d0f4.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
orchestratorSites12261deddd7964dd395b3d073042d0f4.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return orchestratorSites12261deddd7964dd395b3d073042d0f4.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
orchestratorSites12261deddd7964dd395b3d073042d0f4.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestratorSites12261deddd7964dd395b3d073042d0f4.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestratorSites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
orchestratorSites12261deddd7964dd395b3d073042d0f4.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestratorSites12261deddd7964dd395b3d073042d0f4.url(args, options),
    method: 'head',
})

export const orchestratorSites = {
    '/orchestrator/sites': orchestratorSites3f69edf4a99fbd4a58affbd4a354eef2,
    '/orchestrator/projects': orchestratorSitesc59f62f60888ecf6a62c96a79bff9b9a,
    '/environments/{environment}/orchestrator/sites': orchestratorSites336d1c786e70c7f75e54be367b75f56a,
    '/environments/{environment}/orchestrator/projects': orchestratorSites12261deddd7964dd395b3d073042d0f4,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/start'
*/
const starte8620f3b030d71d52b9ed3cfbf535a5d = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: starte8620f3b030d71d52b9ed3cfbf535a5d.url(options),
    method: 'post',
})

starte8620f3b030d71d52b9ed3cfbf535a5d.definition = {
    methods: ["post"],
    url: '/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/start'
*/
starte8620f3b030d71d52b9ed3cfbf535a5d.url = (options?: RouteQueryOptions) => {
    return starte8620f3b030d71d52b9ed3cfbf535a5d.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/start'
*/
starte8620f3b030d71d52b9ed3cfbf535a5d.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: starte8620f3b030d71d52b9ed3cfbf535a5d.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/environments/{environment}/start'
*/
const startbba81c72f14d99b82bff15dd5825dd65 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startbba81c72f14d99b82bff15dd5825dd65.url(args, options),
    method: 'post',
})

startbba81c72f14d99b82bff15dd5825dd65.definition = {
    methods: ["post"],
    url: '/environments/{environment}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/environments/{environment}/start'
*/
startbba81c72f14d99b82bff15dd5825dd65.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return startbba81c72f14d99b82bff15dd5825dd65.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/environments/{environment}/start'
*/
startbba81c72f14d99b82bff15dd5825dd65.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startbba81c72f14d99b82bff15dd5825dd65.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/environments/{environment}/start'
*/
const starteedb10b69e3eb71aeb5f93ecd08234b0 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: starteedb10b69e3eb71aeb5f93ecd08234b0.url(args, options),
    method: 'post',
})

starteedb10b69e3eb71aeb5f93ecd08234b0.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/environments/{environment}/start'
*/
starteedb10b69e3eb71aeb5f93ecd08234b0.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return starteedb10b69e3eb71aeb5f93ecd08234b0.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/environments/{environment}/start'
*/
starteedb10b69e3eb71aeb5f93ecd08234b0.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: starteedb10b69e3eb71aeb5f93ecd08234b0.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/start'
*/
const startb87e66d34ec7402e047314b43db0f740 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startb87e66d34ec7402e047314b43db0f740.url(options),
    method: 'post',
})

startb87e66d34ec7402e047314b43db0f740.definition = {
    methods: ["post"],
    url: '/api/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/start'
*/
startb87e66d34ec7402e047314b43db0f740.url = (options?: RouteQueryOptions) => {
    return startb87e66d34ec7402e047314b43db0f740.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/start'
*/
startb87e66d34ec7402e047314b43db0f740.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startb87e66d34ec7402e047314b43db0f740.url(options),
    method: 'post',
})

export const start = {
    '/start': starte8620f3b030d71d52b9ed3cfbf535a5d,
    '/environments/{environment}/start': startbba81c72f14d99b82bff15dd5825dd65,
    '/api/environments/{environment}/start': starteedb10b69e3eb71aeb5f93ecd08234b0,
    '/api/start': startb87e66d34ec7402e047314b43db0f740,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/stop'
*/
const stopff2634a4b3358988908b7de3cc42552a = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopff2634a4b3358988908b7de3cc42552a.url(options),
    method: 'post',
})

stopff2634a4b3358988908b7de3cc42552a.definition = {
    methods: ["post"],
    url: '/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/stop'
*/
stopff2634a4b3358988908b7de3cc42552a.url = (options?: RouteQueryOptions) => {
    return stopff2634a4b3358988908b7de3cc42552a.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/stop'
*/
stopff2634a4b3358988908b7de3cc42552a.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopff2634a4b3358988908b7de3cc42552a.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/environments/{environment}/stop'
*/
const stop3a0836242701f844ee83bcb7a3d67939 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop3a0836242701f844ee83bcb7a3d67939.url(args, options),
    method: 'post',
})

stop3a0836242701f844ee83bcb7a3d67939.definition = {
    methods: ["post"],
    url: '/environments/{environment}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/environments/{environment}/stop'
*/
stop3a0836242701f844ee83bcb7a3d67939.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return stop3a0836242701f844ee83bcb7a3d67939.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/environments/{environment}/stop'
*/
stop3a0836242701f844ee83bcb7a3d67939.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop3a0836242701f844ee83bcb7a3d67939.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/environments/{environment}/stop'
*/
const stop514f8a117b1b8fb3c540470b30763110 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop514f8a117b1b8fb3c540470b30763110.url(args, options),
    method: 'post',
})

stop514f8a117b1b8fb3c540470b30763110.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/environments/{environment}/stop'
*/
stop514f8a117b1b8fb3c540470b30763110.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return stop514f8a117b1b8fb3c540470b30763110.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/environments/{environment}/stop'
*/
stop514f8a117b1b8fb3c540470b30763110.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop514f8a117b1b8fb3c540470b30763110.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/stop'
*/
const stop234fcc4ac9163f9d55a5c7024c8b0a98 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop234fcc4ac9163f9d55a5c7024c8b0a98.url(options),
    method: 'post',
})

stop234fcc4ac9163f9d55a5c7024c8b0a98.definition = {
    methods: ["post"],
    url: '/api/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/stop'
*/
stop234fcc4ac9163f9d55a5c7024c8b0a98.url = (options?: RouteQueryOptions) => {
    return stop234fcc4ac9163f9d55a5c7024c8b0a98.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/stop'
*/
stop234fcc4ac9163f9d55a5c7024c8b0a98.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop234fcc4ac9163f9d55a5c7024c8b0a98.url(options),
    method: 'post',
})

export const stop = {
    '/stop': stopff2634a4b3358988908b7de3cc42552a,
    '/environments/{environment}/stop': stop3a0836242701f844ee83bcb7a3d67939,
    '/api/environments/{environment}/stop': stop514f8a117b1b8fb3c540470b30763110,
    '/api/stop': stop234fcc4ac9163f9d55a5c7024c8b0a98,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/restart'
*/
const restart42e2654f46a5258fcc3af2631b350911 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart42e2654f46a5258fcc3af2631b350911.url(options),
    method: 'post',
})

restart42e2654f46a5258fcc3af2631b350911.definition = {
    methods: ["post"],
    url: '/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/restart'
*/
restart42e2654f46a5258fcc3af2631b350911.url = (options?: RouteQueryOptions) => {
    return restart42e2654f46a5258fcc3af2631b350911.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/restart'
*/
restart42e2654f46a5258fcc3af2631b350911.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart42e2654f46a5258fcc3af2631b350911.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/environments/{environment}/restart'
*/
const restartaf42b303592297ea0da39723b4cf303d = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartaf42b303592297ea0da39723b4cf303d.url(args, options),
    method: 'post',
})

restartaf42b303592297ea0da39723b4cf303d.definition = {
    methods: ["post"],
    url: '/environments/{environment}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/environments/{environment}/restart'
*/
restartaf42b303592297ea0da39723b4cf303d.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return restartaf42b303592297ea0da39723b4cf303d.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/environments/{environment}/restart'
*/
restartaf42b303592297ea0da39723b4cf303d.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartaf42b303592297ea0da39723b4cf303d.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/environments/{environment}/restart'
*/
const restartf20d796e140854979f5e12d001b0b911 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartf20d796e140854979f5e12d001b0b911.url(args, options),
    method: 'post',
})

restartf20d796e140854979f5e12d001b0b911.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/environments/{environment}/restart'
*/
restartf20d796e140854979f5e12d001b0b911.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return restartf20d796e140854979f5e12d001b0b911.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/environments/{environment}/restart'
*/
restartf20d796e140854979f5e12d001b0b911.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartf20d796e140854979f5e12d001b0b911.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/restart'
*/
const restartb1e0c75473df1386973708b16ca8709d = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartb1e0c75473df1386973708b16ca8709d.url(options),
    method: 'post',
})

restartb1e0c75473df1386973708b16ca8709d.definition = {
    methods: ["post"],
    url: '/api/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/restart'
*/
restartb1e0c75473df1386973708b16ca8709d.url = (options?: RouteQueryOptions) => {
    return restartb1e0c75473df1386973708b16ca8709d.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/restart'
*/
restartb1e0c75473df1386973708b16ca8709d.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartb1e0c75473df1386973708b16ca8709d.url(options),
    method: 'post',
})

export const restart = {
    '/restart': restart42e2654f46a5258fcc3af2631b350911,
    '/environments/{environment}/restart': restartaf42b303592297ea0da39723b4cf303d,
    '/api/environments/{environment}/restart': restartf20d796e140854979f5e12d001b0b911,
    '/api/restart': restartb1e0c75473df1386973708b16ca8709d,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::changePhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/php'
*/
const changePhpf699cbf63766808e183b6eed969af95b = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changePhpf699cbf63766808e183b6eed969af95b.url(options),
    method: 'post',
})

changePhpf699cbf63766808e183b6eed969af95b.definition = {
    methods: ["post"],
    url: '/php',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::changePhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/php'
*/
changePhpf699cbf63766808e183b6eed969af95b.url = (options?: RouteQueryOptions) => {
    return changePhpf699cbf63766808e183b6eed969af95b.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::changePhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/php'
*/
changePhpf699cbf63766808e183b6eed969af95b.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changePhpf699cbf63766808e183b6eed969af95b.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::changePhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/environments/{environment}/php'
*/
const changePhp4becec03bbc3af3752c0641362c16ac7 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changePhp4becec03bbc3af3752c0641362c16ac7.url(args, options),
    method: 'post',
})

changePhp4becec03bbc3af3752c0641362c16ac7.definition = {
    methods: ["post"],
    url: '/environments/{environment}/php',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::changePhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/environments/{environment}/php'
*/
changePhp4becec03bbc3af3752c0641362c16ac7.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return changePhp4becec03bbc3af3752c0641362c16ac7.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::changePhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/environments/{environment}/php'
*/
changePhp4becec03bbc3af3752c0641362c16ac7.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: changePhp4becec03bbc3af3752c0641362c16ac7.url(args, options),
    method: 'post',
})

export const changePhp = {
    '/php': changePhpf699cbf63766808e183b6eed969af95b,
    '/environments/{environment}/php': changePhp4becec03bbc3af3752c0641362c16ac7,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::resetPhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:685
* @route '/php/reset'
*/
const resetPhp1a2a1cc1203813cc97236b38445d3b8a = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPhp1a2a1cc1203813cc97236b38445d3b8a.url(options),
    method: 'post',
})

resetPhp1a2a1cc1203813cc97236b38445d3b8a.definition = {
    methods: ["post"],
    url: '/php/reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::resetPhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:685
* @route '/php/reset'
*/
resetPhp1a2a1cc1203813cc97236b38445d3b8a.url = (options?: RouteQueryOptions) => {
    return resetPhp1a2a1cc1203813cc97236b38445d3b8a.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::resetPhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:685
* @route '/php/reset'
*/
resetPhp1a2a1cc1203813cc97236b38445d3b8a.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPhp1a2a1cc1203813cc97236b38445d3b8a.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::resetPhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:685
* @route '/environments/{environment}/php/reset'
*/
const resetPhp07dfab3a9d16de38af49c28cce87cda7 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPhp07dfab3a9d16de38af49c28cce87cda7.url(args, options),
    method: 'post',
})

resetPhp07dfab3a9d16de38af49c28cce87cda7.definition = {
    methods: ["post"],
    url: '/environments/{environment}/php/reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::resetPhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:685
* @route '/environments/{environment}/php/reset'
*/
resetPhp07dfab3a9d16de38af49c28cce87cda7.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return resetPhp07dfab3a9d16de38af49c28cce87cda7.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::resetPhp
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:685
* @route '/environments/{environment}/php/reset'
*/
resetPhp07dfab3a9d16de38af49c28cce87cda7.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resetPhp07dfab3a9d16de38af49c28cce87cda7.url(args, options),
    method: 'post',
})

export const resetPhp = {
    '/php/reset': resetPhp1a2a1cc1203813cc97236b38445d3b8a,
    '/environments/{environment}/php/reset': resetPhp07dfab3a9d16de38af49c28cce87cda7,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
const availableServices696d83cc057523321ced148b3e2c0e80 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableServices696d83cc057523321ced148b3e2c0e80.url(options),
    method: 'get',
})

availableServices696d83cc057523321ced148b3e2c0e80.definition = {
    methods: ["get","head"],
    url: '/services/available',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
availableServices696d83cc057523321ced148b3e2c0e80.url = (options?: RouteQueryOptions) => {
    return availableServices696d83cc057523321ced148b3e2c0e80.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
availableServices696d83cc057523321ced148b3e2c0e80.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableServices696d83cc057523321ced148b3e2c0e80.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
availableServices696d83cc057523321ced148b3e2c0e80.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableServices696d83cc057523321ced148b3e2c0e80.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
const availableServices2ccf304e67472ac205f0a675d2612fff = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableServices2ccf304e67472ac205f0a675d2612fff.url(args, options),
    method: 'get',
})

availableServices2ccf304e67472ac205f0a675d2612fff.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services/available',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
availableServices2ccf304e67472ac205f0a675d2612fff.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return availableServices2ccf304e67472ac205f0a675d2612fff.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
availableServices2ccf304e67472ac205f0a675d2612fff.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableServices2ccf304e67472ac205f0a675d2612fff.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
availableServices2ccf304e67472ac205f0a675d2612fff.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableServices2ccf304e67472ac205f0a675d2612fff.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/api/environments/{environment}/services/available'
*/
const availableServicescfd2392e7134d95ea01ab14d3f3d6617 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableServicescfd2392e7134d95ea01ab14d3f3d6617.url(args, options),
    method: 'get',
})

availableServicescfd2392e7134d95ea01ab14d3f3d6617.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/services/available',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/api/environments/{environment}/services/available'
*/
availableServicescfd2392e7134d95ea01ab14d3f3d6617.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return availableServicescfd2392e7134d95ea01ab14d3f3d6617.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/api/environments/{environment}/services/available'
*/
availableServicescfd2392e7134d95ea01ab14d3f3d6617.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availableServicescfd2392e7134d95ea01ab14d3f3d6617.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::availableServices
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/api/environments/{environment}/services/available'
*/
availableServicescfd2392e7134d95ea01ab14d3f3d6617.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availableServicescfd2392e7134d95ea01ab14d3f3d6617.url(args, options),
    method: 'head',
})

export const availableServices = {
    '/services/available': availableServices696d83cc057523321ced148b3e2c0e80,
    '/environments/{environment}/services/available': availableServices2ccf304e67472ac205f0a675d2612fff,
    '/api/environments/{environment}/services/available': availableServicescfd2392e7134d95ea01ab14d3f3d6617,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/services/{service}/start'
*/
const startService69a046681a21ad12b3f6ed3d7854c444 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startService69a046681a21ad12b3f6ed3d7854c444.url(args, options),
    method: 'post',
})

startService69a046681a21ad12b3f6ed3d7854c444.definition = {
    methods: ["post"],
    url: '/services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/services/{service}/start'
*/
startService69a046681a21ad12b3f6ed3d7854c444.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return startService69a046681a21ad12b3f6ed3d7854c444.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/services/{service}/start'
*/
startService69a046681a21ad12b3f6ed3d7854c444.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startService69a046681a21ad12b3f6ed3d7854c444.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/environments/{environment}/services/{service}/start'
*/
const startServiced8e81fa071feb225b0016bb510f10c12 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startServiced8e81fa071feb225b0016bb510f10c12.url(args, options),
    method: 'post',
})

startServiced8e81fa071feb225b0016bb510f10c12.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/environments/{environment}/services/{service}/start'
*/
startServiced8e81fa071feb225b0016bb510f10c12.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return startServiced8e81fa071feb225b0016bb510f10c12.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/environments/{environment}/services/{service}/start'
*/
startServiced8e81fa071feb225b0016bb510f10c12.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startServiced8e81fa071feb225b0016bb510f10c12.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/api/environments/{environment}/services/{service}/start'
*/
const startService79568550ac416da0bfd5c482f3c05ac5 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startService79568550ac416da0bfd5c482f3c05ac5.url(args, options),
    method: 'post',
})

startService79568550ac416da0bfd5c482f3c05ac5.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/api/environments/{environment}/services/{service}/start'
*/
startService79568550ac416da0bfd5c482f3c05ac5.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return startService79568550ac416da0bfd5c482f3c05ac5.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/api/environments/{environment}/services/{service}/start'
*/
startService79568550ac416da0bfd5c482f3c05ac5.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startService79568550ac416da0bfd5c482f3c05ac5.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/api/services/{service}/start'
*/
const startServiceb339bfb6ef9dbfd46b2c25e5afbceda2 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startServiceb339bfb6ef9dbfd46b2c25e5afbceda2.url(args, options),
    method: 'post',
})

startServiceb339bfb6ef9dbfd46b2c25e5afbceda2.definition = {
    methods: ["post"],
    url: '/api/services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/api/services/{service}/start'
*/
startServiceb339bfb6ef9dbfd46b2c25e5afbceda2.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return startServiceb339bfb6ef9dbfd46b2c25e5afbceda2.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/api/services/{service}/start'
*/
startServiceb339bfb6ef9dbfd46b2c25e5afbceda2.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startServiceb339bfb6ef9dbfd46b2c25e5afbceda2.url(args, options),
    method: 'post',
})

export const startService = {
    '/services/{service}/start': startService69a046681a21ad12b3f6ed3d7854c444,
    '/environments/{environment}/services/{service}/start': startServiced8e81fa071feb225b0016bb510f10c12,
    '/api/environments/{environment}/services/{service}/start': startService79568550ac416da0bfd5c482f3c05ac5,
    '/api/services/{service}/start': startServiceb339bfb6ef9dbfd46b2c25e5afbceda2,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/services/{service}/stop'
*/
const stopService2ac2f44bd8651c230333e43a6e6c9cae = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService2ac2f44bd8651c230333e43a6e6c9cae.url(args, options),
    method: 'post',
})

stopService2ac2f44bd8651c230333e43a6e6c9cae.definition = {
    methods: ["post"],
    url: '/services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/services/{service}/stop'
*/
stopService2ac2f44bd8651c230333e43a6e6c9cae.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return stopService2ac2f44bd8651c230333e43a6e6c9cae.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/services/{service}/stop'
*/
stopService2ac2f44bd8651c230333e43a6e6c9cae.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService2ac2f44bd8651c230333e43a6e6c9cae.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/environments/{environment}/services/{service}/stop'
*/
const stopService0e29bdafbe478119ac0327aca00edc88 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService0e29bdafbe478119ac0327aca00edc88.url(args, options),
    method: 'post',
})

stopService0e29bdafbe478119ac0327aca00edc88.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/environments/{environment}/services/{service}/stop'
*/
stopService0e29bdafbe478119ac0327aca00edc88.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return stopService0e29bdafbe478119ac0327aca00edc88.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/environments/{environment}/services/{service}/stop'
*/
stopService0e29bdafbe478119ac0327aca00edc88.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService0e29bdafbe478119ac0327aca00edc88.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/api/environments/{environment}/services/{service}/stop'
*/
const stopService35fed42137c3f4e13833cf377bae7b98 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService35fed42137c3f4e13833cf377bae7b98.url(args, options),
    method: 'post',
})

stopService35fed42137c3f4e13833cf377bae7b98.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/api/environments/{environment}/services/{service}/stop'
*/
stopService35fed42137c3f4e13833cf377bae7b98.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return stopService35fed42137c3f4e13833cf377bae7b98.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/api/environments/{environment}/services/{service}/stop'
*/
stopService35fed42137c3f4e13833cf377bae7b98.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService35fed42137c3f4e13833cf377bae7b98.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/api/services/{service}/stop'
*/
const stopService6948f8a4c6156da4f9aebe2c1965cb6b = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService6948f8a4c6156da4f9aebe2c1965cb6b.url(args, options),
    method: 'post',
})

stopService6948f8a4c6156da4f9aebe2c1965cb6b.definition = {
    methods: ["post"],
    url: '/api/services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/api/services/{service}/stop'
*/
stopService6948f8a4c6156da4f9aebe2c1965cb6b.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return stopService6948f8a4c6156da4f9aebe2c1965cb6b.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/api/services/{service}/stop'
*/
stopService6948f8a4c6156da4f9aebe2c1965cb6b.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopService6948f8a4c6156da4f9aebe2c1965cb6b.url(args, options),
    method: 'post',
})

export const stopService = {
    '/services/{service}/stop': stopService2ac2f44bd8651c230333e43a6e6c9cae,
    '/environments/{environment}/services/{service}/stop': stopService0e29bdafbe478119ac0327aca00edc88,
    '/api/environments/{environment}/services/{service}/stop': stopService35fed42137c3f4e13833cf377bae7b98,
    '/api/services/{service}/stop': stopService6948f8a4c6156da4f9aebe2c1965cb6b,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/services/{service}/restart'
*/
const restartService4c6f233a2fc8bb28e933b9f84c521f00 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartService4c6f233a2fc8bb28e933b9f84c521f00.url(args, options),
    method: 'post',
})

restartService4c6f233a2fc8bb28e933b9f84c521f00.definition = {
    methods: ["post"],
    url: '/services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/services/{service}/restart'
*/
restartService4c6f233a2fc8bb28e933b9f84c521f00.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return restartService4c6f233a2fc8bb28e933b9f84c521f00.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/services/{service}/restart'
*/
restartService4c6f233a2fc8bb28e933b9f84c521f00.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartService4c6f233a2fc8bb28e933b9f84c521f00.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/environments/{environment}/services/{service}/restart'
*/
const restartServiceb46f3d9034650bc6f0ee2717a6c6c490 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartServiceb46f3d9034650bc6f0ee2717a6c6c490.url(args, options),
    method: 'post',
})

restartServiceb46f3d9034650bc6f0ee2717a6c6c490.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/environments/{environment}/services/{service}/restart'
*/
restartServiceb46f3d9034650bc6f0ee2717a6c6c490.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return restartServiceb46f3d9034650bc6f0ee2717a6c6c490.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/environments/{environment}/services/{service}/restart'
*/
restartServiceb46f3d9034650bc6f0ee2717a6c6c490.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartServiceb46f3d9034650bc6f0ee2717a6c6c490.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/api/environments/{environment}/services/{service}/restart'
*/
const restartService4838eb9f5edebbdf1bdb3328d83862a2 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartService4838eb9f5edebbdf1bdb3328d83862a2.url(args, options),
    method: 'post',
})

restartService4838eb9f5edebbdf1bdb3328d83862a2.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/api/environments/{environment}/services/{service}/restart'
*/
restartService4838eb9f5edebbdf1bdb3328d83862a2.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return restartService4838eb9f5edebbdf1bdb3328d83862a2.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/api/environments/{environment}/services/{service}/restart'
*/
restartService4838eb9f5edebbdf1bdb3328d83862a2.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartService4838eb9f5edebbdf1bdb3328d83862a2.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/api/services/{service}/restart'
*/
const restartService6714ea75626b83eb3bb08377aac93584 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartService6714ea75626b83eb3bb08377aac93584.url(args, options),
    method: 'post',
})

restartService6714ea75626b83eb3bb08377aac93584.definition = {
    methods: ["post"],
    url: '/api/services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/api/services/{service}/restart'
*/
restartService6714ea75626b83eb3bb08377aac93584.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return restartService6714ea75626b83eb3bb08377aac93584.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/api/services/{service}/restart'
*/
restartService6714ea75626b83eb3bb08377aac93584.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartService6714ea75626b83eb3bb08377aac93584.url(args, options),
    method: 'post',
})

export const restartService = {
    '/services/{service}/restart': restartService4c6f233a2fc8bb28e933b9f84c521f00,
    '/environments/{environment}/services/{service}/restart': restartServiceb46f3d9034650bc6f0ee2717a6c6c490,
    '/api/environments/{environment}/services/{service}/restart': restartService4838eb9f5edebbdf1bdb3328d83862a2,
    '/api/services/{service}/restart': restartService6714ea75626b83eb3bb08377aac93584,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/host-services/{service}/start'
*/
const startHostServicea70de95b8947c3141abfba883bc7310a = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startHostServicea70de95b8947c3141abfba883bc7310a.url(args, options),
    method: 'post',
})

startHostServicea70de95b8947c3141abfba883bc7310a.definition = {
    methods: ["post"],
    url: '/host-services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/host-services/{service}/start'
*/
startHostServicea70de95b8947c3141abfba883bc7310a.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return startHostServicea70de95b8947c3141abfba883bc7310a.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/host-services/{service}/start'
*/
startHostServicea70de95b8947c3141abfba883bc7310a.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startHostServicea70de95b8947c3141abfba883bc7310a.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/environments/{environment}/host-services/{service}/start'
*/
const startHostServicebaf7f5e766d365c20a027dec0945dd63 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startHostServicebaf7f5e766d365c20a027dec0945dd63.url(args, options),
    method: 'post',
})

startHostServicebaf7f5e766d365c20a027dec0945dd63.definition = {
    methods: ["post"],
    url: '/environments/{environment}/host-services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/environments/{environment}/host-services/{service}/start'
*/
startHostServicebaf7f5e766d365c20a027dec0945dd63.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return startHostServicebaf7f5e766d365c20a027dec0945dd63.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/environments/{environment}/host-services/{service}/start'
*/
startHostServicebaf7f5e766d365c20a027dec0945dd63.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startHostServicebaf7f5e766d365c20a027dec0945dd63.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/api/environments/{environment}/host-services/{service}/start'
*/
const startHostServicee0be8bbb1a9007e459226801f9c2f864 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startHostServicee0be8bbb1a9007e459226801f9c2f864.url(args, options),
    method: 'post',
})

startHostServicee0be8bbb1a9007e459226801f9c2f864.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/host-services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/api/environments/{environment}/host-services/{service}/start'
*/
startHostServicee0be8bbb1a9007e459226801f9c2f864.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return startHostServicee0be8bbb1a9007e459226801f9c2f864.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::startHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/api/environments/{environment}/host-services/{service}/start'
*/
startHostServicee0be8bbb1a9007e459226801f9c2f864.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: startHostServicee0be8bbb1a9007e459226801f9c2f864.url(args, options),
    method: 'post',
})

export const startHostService = {
    '/host-services/{service}/start': startHostServicea70de95b8947c3141abfba883bc7310a,
    '/environments/{environment}/host-services/{service}/start': startHostServicebaf7f5e766d365c20a027dec0945dd63,
    '/api/environments/{environment}/host-services/{service}/start': startHostServicee0be8bbb1a9007e459226801f9c2f864,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/host-services/{service}/stop'
*/
const stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc.url(args, options),
    method: 'post',
})

stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc.definition = {
    methods: ["post"],
    url: '/host-services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/host-services/{service}/stop'
*/
stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/host-services/{service}/stop'
*/
stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/environments/{environment}/host-services/{service}/stop'
*/
const stopHostService866986b402225de9b480a7d2471f5199 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopHostService866986b402225de9b480a7d2471f5199.url(args, options),
    method: 'post',
})

stopHostService866986b402225de9b480a7d2471f5199.definition = {
    methods: ["post"],
    url: '/environments/{environment}/host-services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/environments/{environment}/host-services/{service}/stop'
*/
stopHostService866986b402225de9b480a7d2471f5199.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return stopHostService866986b402225de9b480a7d2471f5199.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/environments/{environment}/host-services/{service}/stop'
*/
stopHostService866986b402225de9b480a7d2471f5199.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopHostService866986b402225de9b480a7d2471f5199.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/api/environments/{environment}/host-services/{service}/stop'
*/
const stopHostService917f1f4fbb1cab3d853a5796ac1b8a46 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopHostService917f1f4fbb1cab3d853a5796ac1b8a46.url(args, options),
    method: 'post',
})

stopHostService917f1f4fbb1cab3d853a5796ac1b8a46.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/host-services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/api/environments/{environment}/host-services/{service}/stop'
*/
stopHostService917f1f4fbb1cab3d853a5796ac1b8a46.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return stopHostService917f1f4fbb1cab3d853a5796ac1b8a46.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stopHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/api/environments/{environment}/host-services/{service}/stop'
*/
stopHostService917f1f4fbb1cab3d853a5796ac1b8a46.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stopHostService917f1f4fbb1cab3d853a5796ac1b8a46.url(args, options),
    method: 'post',
})

export const stopHostService = {
    '/host-services/{service}/stop': stopHostServiceb8bb6b178b7de9fb84adde63fe0ea7dc,
    '/environments/{environment}/host-services/{service}/stop': stopHostService866986b402225de9b480a7d2471f5199,
    '/api/environments/{environment}/host-services/{service}/stop': stopHostService917f1f4fbb1cab3d853a5796ac1b8a46,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/host-services/{service}/restart'
*/
const restartHostService7e668d81cacbdb446e88a5e2bf8448a0 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartHostService7e668d81cacbdb446e88a5e2bf8448a0.url(args, options),
    method: 'post',
})

restartHostService7e668d81cacbdb446e88a5e2bf8448a0.definition = {
    methods: ["post"],
    url: '/host-services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/host-services/{service}/restart'
*/
restartHostService7e668d81cacbdb446e88a5e2bf8448a0.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return restartHostService7e668d81cacbdb446e88a5e2bf8448a0.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/host-services/{service}/restart'
*/
restartHostService7e668d81cacbdb446e88a5e2bf8448a0.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartHostService7e668d81cacbdb446e88a5e2bf8448a0.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/environments/{environment}/host-services/{service}/restart'
*/
const restartHostService934df996fed0075a45d1ec60aee9696a = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartHostService934df996fed0075a45d1ec60aee9696a.url(args, options),
    method: 'post',
})

restartHostService934df996fed0075a45d1ec60aee9696a.definition = {
    methods: ["post"],
    url: '/environments/{environment}/host-services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/environments/{environment}/host-services/{service}/restart'
*/
restartHostService934df996fed0075a45d1ec60aee9696a.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return restartHostService934df996fed0075a45d1ec60aee9696a.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/environments/{environment}/host-services/{service}/restart'
*/
restartHostService934df996fed0075a45d1ec60aee9696a.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartHostService934df996fed0075a45d1ec60aee9696a.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/api/environments/{environment}/host-services/{service}/restart'
*/
const restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0.url(args, options),
    method: 'post',
})

restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/host-services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/api/environments/{environment}/host-services/{service}/restart'
*/
restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restartHostService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/api/environments/{environment}/host-services/{service}/restart'
*/
restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0.url(args, options),
    method: 'post',
})

export const restartHostService = {
    '/host-services/{service}/restart': restartHostService7e668d81cacbdb446e88a5e2bf8448a0,
    '/environments/{environment}/host-services/{service}/restart': restartHostService934df996fed0075a45d1ec60aee9696a,
    '/api/environments/{environment}/host-services/{service}/restart': restartHostService5eb8d328a46df9f2c2fbf0ff6ad556f0,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
const serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.url(args, options),
    method: 'get',
})

serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.definition = {
    methods: ["get","head"],
    url: '/services/{service}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.get = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.head = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
const serviceLogs7cfc83cde278b475db4fef01bb32ffa3 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceLogs7cfc83cde278b475db4fef01bb32ffa3.url(args, options),
    method: 'get',
})

serviceLogs7cfc83cde278b475db4fef01bb32ffa3.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services/{service}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
serviceLogs7cfc83cde278b475db4fef01bb32ffa3.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return serviceLogs7cfc83cde278b475db4fef01bb32ffa3.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
serviceLogs7cfc83cde278b475db4fef01bb32ffa3.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceLogs7cfc83cde278b475db4fef01bb32ffa3.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
serviceLogs7cfc83cde278b475db4fef01bb32ffa3.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serviceLogs7cfc83cde278b475db4fef01bb32ffa3.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/api/environments/{environment}/services/{service}/logs'
*/
const serviceLogs5dcf916db207ce79af35c2e6cbabbbf2 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.url(args, options),
    method: 'get',
})

serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/services/{service}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/api/environments/{environment}/services/{service}/logs'
*/
serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/api/environments/{environment}/services/{service}/logs'
*/
serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/api/environments/{environment}/services/{service}/logs'
*/
serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serviceLogs5dcf916db207ce79af35c2e6cbabbbf2.url(args, options),
    method: 'head',
})

export const serviceLogs = {
    '/services/{service}/logs': serviceLogscb4aa32ee2532fbdd1ae442b6b584ee5,
    '/environments/{environment}/services/{service}/logs': serviceLogs7cfc83cde278b475db4fef01bb32ffa3,
    '/api/environments/{environment}/services/{service}/logs': serviceLogs5dcf916db207ce79af35c2e6cbabbbf2,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/services/{service}/enable'
*/
const enableService15a44e3ec84dca5169c618dfed14a3c7 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableService15a44e3ec84dca5169c618dfed14a3c7.url(args, options),
    method: 'post',
})

enableService15a44e3ec84dca5169c618dfed14a3c7.definition = {
    methods: ["post"],
    url: '/services/{service}/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/services/{service}/enable'
*/
enableService15a44e3ec84dca5169c618dfed14a3c7.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return enableService15a44e3ec84dca5169c618dfed14a3c7.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/services/{service}/enable'
*/
enableService15a44e3ec84dca5169c618dfed14a3c7.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableService15a44e3ec84dca5169c618dfed14a3c7.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/environments/{environment}/services/{service}/enable'
*/
const enableService999b4b0813c7c4f5898142fe7eb10abc = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableService999b4b0813c7c4f5898142fe7eb10abc.url(args, options),
    method: 'post',
})

enableService999b4b0813c7c4f5898142fe7eb10abc.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/environments/{environment}/services/{service}/enable'
*/
enableService999b4b0813c7c4f5898142fe7eb10abc.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return enableService999b4b0813c7c4f5898142fe7eb10abc.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/environments/{environment}/services/{service}/enable'
*/
enableService999b4b0813c7c4f5898142fe7eb10abc.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableService999b4b0813c7c4f5898142fe7eb10abc.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/api/environments/{environment}/services/{service}/enable'
*/
const enableServicec3de7b8152f3861bf40ede8018fe5c45 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableServicec3de7b8152f3861bf40ede8018fe5c45.url(args, options),
    method: 'post',
})

enableServicec3de7b8152f3861bf40ede8018fe5c45.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/services/{service}/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/api/environments/{environment}/services/{service}/enable'
*/
enableServicec3de7b8152f3861bf40ede8018fe5c45.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return enableServicec3de7b8152f3861bf40ede8018fe5c45.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/api/environments/{environment}/services/{service}/enable'
*/
enableServicec3de7b8152f3861bf40ede8018fe5c45.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableServicec3de7b8152f3861bf40ede8018fe5c45.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/api/services/{service}/enable'
*/
const enableService408bc23445e1a67afea695fbcb9c9fa0 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableService408bc23445e1a67afea695fbcb9c9fa0.url(args, options),
    method: 'post',
})

enableService408bc23445e1a67afea695fbcb9c9fa0.definition = {
    methods: ["post"],
    url: '/api/services/{service}/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/api/services/{service}/enable'
*/
enableService408bc23445e1a67afea695fbcb9c9fa0.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return enableService408bc23445e1a67afea695fbcb9c9fa0.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/api/services/{service}/enable'
*/
enableService408bc23445e1a67afea695fbcb9c9fa0.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enableService408bc23445e1a67afea695fbcb9c9fa0.url(args, options),
    method: 'post',
})

export const enableService = {
    '/services/{service}/enable': enableService15a44e3ec84dca5169c618dfed14a3c7,
    '/environments/{environment}/services/{service}/enable': enableService999b4b0813c7c4f5898142fe7eb10abc,
    '/api/environments/{environment}/services/{service}/enable': enableServicec3de7b8152f3861bf40ede8018fe5c45,
    '/api/services/{service}/enable': enableService408bc23445e1a67afea695fbcb9c9fa0,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/services/{service}'
*/
const disableService000b2142c88a537855e36d5540b0e8ee = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disableService000b2142c88a537855e36d5540b0e8ee.url(args, options),
    method: 'delete',
})

disableService000b2142c88a537855e36d5540b0e8ee.definition = {
    methods: ["delete"],
    url: '/services/{service}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/services/{service}'
*/
disableService000b2142c88a537855e36d5540b0e8ee.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return disableService000b2142c88a537855e36d5540b0e8ee.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/services/{service}'
*/
disableService000b2142c88a537855e36d5540b0e8ee.delete = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disableService000b2142c88a537855e36d5540b0e8ee.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/environments/{environment}/services/{service}'
*/
const disableService87be0ff86da324b28455a16c57512b91 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disableService87be0ff86da324b28455a16c57512b91.url(args, options),
    method: 'delete',
})

disableService87be0ff86da324b28455a16c57512b91.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/services/{service}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/environments/{environment}/services/{service}'
*/
disableService87be0ff86da324b28455a16c57512b91.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return disableService87be0ff86da324b28455a16c57512b91.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/environments/{environment}/services/{service}'
*/
disableService87be0ff86da324b28455a16c57512b91.delete = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disableService87be0ff86da324b28455a16c57512b91.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/api/environments/{environment}/services/{service}'
*/
const disableService78afa45194a63eff9ce72817d1b965de = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disableService78afa45194a63eff9ce72817d1b965de.url(args, options),
    method: 'delete',
})

disableService78afa45194a63eff9ce72817d1b965de.definition = {
    methods: ["delete"],
    url: '/api/environments/{environment}/services/{service}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/api/environments/{environment}/services/{service}'
*/
disableService78afa45194a63eff9ce72817d1b965de.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return disableService78afa45194a63eff9ce72817d1b965de.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/api/environments/{environment}/services/{service}'
*/
disableService78afa45194a63eff9ce72817d1b965de.delete = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disableService78afa45194a63eff9ce72817d1b965de.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/api/services/{service}/disable'
*/
const disableService6052b2da07b834e11eb25bde4270183c = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disableService6052b2da07b834e11eb25bde4270183c.url(args, options),
    method: 'post',
})

disableService6052b2da07b834e11eb25bde4270183c.definition = {
    methods: ["post"],
    url: '/api/services/{service}/disable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/api/services/{service}/disable'
*/
disableService6052b2da07b834e11eb25bde4270183c.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return disableService6052b2da07b834e11eb25bde4270183c.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disableService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/api/services/{service}/disable'
*/
disableService6052b2da07b834e11eb25bde4270183c.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disableService6052b2da07b834e11eb25bde4270183c.url(args, options),
    method: 'post',
})

export const disableService = {
    '/services/{service}': disableService000b2142c88a537855e36d5540b0e8ee,
    '/environments/{environment}/services/{service}': disableService87be0ff86da324b28455a16c57512b91,
    '/api/environments/{environment}/services/{service}': disableService78afa45194a63eff9ce72817d1b965de,
    '/api/services/{service}/disable': disableService6052b2da07b834e11eb25bde4270183c,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/services/{service}/config'
*/
const configureService6c87ca91da4b51ceb96d9e775e4b764f = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: configureService6c87ca91da4b51ceb96d9e775e4b764f.url(args, options),
    method: 'put',
})

configureService6c87ca91da4b51ceb96d9e775e4b764f.definition = {
    methods: ["put"],
    url: '/services/{service}/config',
} satisfies RouteDefinition<["put"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/services/{service}/config'
*/
configureService6c87ca91da4b51ceb96d9e775e4b764f.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return configureService6c87ca91da4b51ceb96d9e775e4b764f.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/services/{service}/config'
*/
configureService6c87ca91da4b51ceb96d9e775e4b764f.put = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: configureService6c87ca91da4b51ceb96d9e775e4b764f.url(args, options),
    method: 'put',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/environments/{environment}/services/{service}/config'
*/
const configureServiced19d94f23b1d601bb0d3634566c64251 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: configureServiced19d94f23b1d601bb0d3634566c64251.url(args, options),
    method: 'put',
})

configureServiced19d94f23b1d601bb0d3634566c64251.definition = {
    methods: ["put"],
    url: '/environments/{environment}/services/{service}/config',
} satisfies RouteDefinition<["put"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/environments/{environment}/services/{service}/config'
*/
configureServiced19d94f23b1d601bb0d3634566c64251.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return configureServiced19d94f23b1d601bb0d3634566c64251.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/environments/{environment}/services/{service}/config'
*/
configureServiced19d94f23b1d601bb0d3634566c64251.put = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: configureServiced19d94f23b1d601bb0d3634566c64251.url(args, options),
    method: 'put',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/api/environments/{environment}/services/{service}/config'
*/
const configureService1a30773445c19092ec4236afd15f92fa = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: configureService1a30773445c19092ec4236afd15f92fa.url(args, options),
    method: 'put',
})

configureService1a30773445c19092ec4236afd15f92fa.definition = {
    methods: ["put"],
    url: '/api/environments/{environment}/services/{service}/config',
} satisfies RouteDefinition<["put"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/api/environments/{environment}/services/{service}/config'
*/
configureService1a30773445c19092ec4236afd15f92fa.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return configureService1a30773445c19092ec4236afd15f92fa.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::configureService
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/api/environments/{environment}/services/{service}/config'
*/
configureService1a30773445c19092ec4236afd15f92fa.put = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: configureService1a30773445c19092ec4236afd15f92fa.url(args, options),
    method: 'put',
})

export const configureService = {
    '/services/{service}/config': configureService6c87ca91da4b51ceb96d9e775e4b764f,
    '/environments/{environment}/services/{service}/config': configureServiced19d94f23b1d601bb0d3634566c64251,
    '/api/environments/{environment}/services/{service}/config': configureService1a30773445c19092ec4236afd15f92fa,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
const serviceInfoaad94c896ef83e769f23b552cf213fd2 = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceInfoaad94c896ef83e769f23b552cf213fd2.url(args, options),
    method: 'get',
})

serviceInfoaad94c896ef83e769f23b552cf213fd2.definition = {
    methods: ["get","head"],
    url: '/services/{service}/info',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
serviceInfoaad94c896ef83e769f23b552cf213fd2.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return serviceInfoaad94c896ef83e769f23b552cf213fd2.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
serviceInfoaad94c896ef83e769f23b552cf213fd2.get = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceInfoaad94c896ef83e769f23b552cf213fd2.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
serviceInfoaad94c896ef83e769f23b552cf213fd2.head = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serviceInfoaad94c896ef83e769f23b552cf213fd2.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
const serviceInfo25019a124074ebb6439c33fccb1f3045 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceInfo25019a124074ebb6439c33fccb1f3045.url(args, options),
    method: 'get',
})

serviceInfo25019a124074ebb6439c33fccb1f3045.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services/{service}/info',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
serviceInfo25019a124074ebb6439c33fccb1f3045.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return serviceInfo25019a124074ebb6439c33fccb1f3045.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
serviceInfo25019a124074ebb6439c33fccb1f3045.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceInfo25019a124074ebb6439c33fccb1f3045.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
serviceInfo25019a124074ebb6439c33fccb1f3045.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serviceInfo25019a124074ebb6439c33fccb1f3045.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/api/environments/{environment}/services/{service}/info'
*/
const serviceInfo8cb7fc8bec450f9555be873d8ca91ba7 = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.url(args, options),
    method: 'get',
})

serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/services/{service}/info',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/api/environments/{environment}/services/{service}/info'
*/
serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/api/environments/{environment}/services/{service}/info'
*/
serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::serviceInfo
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/api/environments/{environment}/services/{service}/info'
*/
serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: serviceInfo8cb7fc8bec450f9555be873d8ca91ba7.url(args, options),
    method: 'head',
})

export const serviceInfo = {
    '/services/{service}/info': serviceInfoaad94c896ef83e769f23b552cf213fd2,
    '/environments/{environment}/services/{service}/info': serviceInfo25019a124074ebb6439c33fccb1f3045,
    '/api/environments/{environment}/services/{service}/info': serviceInfo8cb7fc8bec450f9555be873d8ca91ba7,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::saveConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:713
* @route '/config'
*/
const saveConfigc2432a114dc4d5948c97b5caaeb41aac = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveConfigc2432a114dc4d5948c97b5caaeb41aac.url(options),
    method: 'post',
})

saveConfigc2432a114dc4d5948c97b5caaeb41aac.definition = {
    methods: ["post"],
    url: '/config',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::saveConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:713
* @route '/config'
*/
saveConfigc2432a114dc4d5948c97b5caaeb41aac.url = (options?: RouteQueryOptions) => {
    return saveConfigc2432a114dc4d5948c97b5caaeb41aac.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::saveConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:713
* @route '/config'
*/
saveConfigc2432a114dc4d5948c97b5caaeb41aac.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveConfigc2432a114dc4d5948c97b5caaeb41aac.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::saveConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:713
* @route '/environments/{environment}/config'
*/
const saveConfig524fb2dfe15dadce5d84e960fe3bbe30 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveConfig524fb2dfe15dadce5d84e960fe3bbe30.url(args, options),
    method: 'post',
})

saveConfig524fb2dfe15dadce5d84e960fe3bbe30.definition = {
    methods: ["post"],
    url: '/environments/{environment}/config',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::saveConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:713
* @route '/environments/{environment}/config'
*/
saveConfig524fb2dfe15dadce5d84e960fe3bbe30.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return saveConfig524fb2dfe15dadce5d84e960fe3bbe30.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::saveConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:713
* @route '/environments/{environment}/config'
*/
saveConfig524fb2dfe15dadce5d84e960fe3bbe30.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: saveConfig524fb2dfe15dadce5d84e960fe3bbe30.url(args, options),
    method: 'post',
})

export const saveConfig = {
    '/config': saveConfigc2432a114dc4d5948c97b5caaeb41aac,
    '/environments/{environment}/config': saveConfig524fb2dfe15dadce5d84e960fe3bbe30,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
const getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.url(options),
    method: 'get',
})

getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.definition = {
    methods: ["get","head"],
    url: '/reverb-config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.url = (options?: RouteQueryOptions) => {
    return getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
const getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.url(args, options),
    method: 'get',
})

getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/reverb-config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getReverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42.url(args, options),
    method: 'head',
})

export const getReverbConfig = {
    '/reverb-config': getReverbConfigfd3d6003ddedfc9b3cb0a17c3af18def,
    '/environments/{environment}/reverb-config': getReverbConfig522e4f62a0d3ec2d954d5e91437d1b42,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkWorktree
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:835
* @route '/worktrees/unlink'
*/
const unlinkWorktreed161876af233367d847f3e7b661a3714 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unlinkWorktreed161876af233367d847f3e7b661a3714.url(options),
    method: 'post',
})

unlinkWorktreed161876af233367d847f3e7b661a3714.definition = {
    methods: ["post"],
    url: '/worktrees/unlink',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkWorktree
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:835
* @route '/worktrees/unlink'
*/
unlinkWorktreed161876af233367d847f3e7b661a3714.url = (options?: RouteQueryOptions) => {
    return unlinkWorktreed161876af233367d847f3e7b661a3714.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkWorktree
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:835
* @route '/worktrees/unlink'
*/
unlinkWorktreed161876af233367d847f3e7b661a3714.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unlinkWorktreed161876af233367d847f3e7b661a3714.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkWorktree
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:835
* @route '/environments/{environment}/worktrees/unlink'
*/
const unlinkWorktreeab9ddd4e491f1242577144c446cb50af = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unlinkWorktreeab9ddd4e491f1242577144c446cb50af.url(args, options),
    method: 'post',
})

unlinkWorktreeab9ddd4e491f1242577144c446cb50af.definition = {
    methods: ["post"],
    url: '/environments/{environment}/worktrees/unlink',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkWorktree
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:835
* @route '/environments/{environment}/worktrees/unlink'
*/
unlinkWorktreeab9ddd4e491f1242577144c446cb50af.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return unlinkWorktreeab9ddd4e491f1242577144c446cb50af.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkWorktree
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:835
* @route '/environments/{environment}/worktrees/unlink'
*/
unlinkWorktreeab9ddd4e491f1242577144c446cb50af.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unlinkWorktreeab9ddd4e491f1242577144c446cb50af.url(args, options),
    method: 'post',
})

export const unlinkWorktree = {
    '/worktrees/unlink': unlinkWorktreed161876af233367d847f3e7b661a3714,
    '/environments/{environment}/worktrees/unlink': unlinkWorktreeab9ddd4e491f1242577144c446cb50af,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::refreshWorktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:854
* @route '/worktrees/refresh'
*/
const refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec.url(options),
    method: 'post',
})

refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec.definition = {
    methods: ["post"],
    url: '/worktrees/refresh',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::refreshWorktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:854
* @route '/worktrees/refresh'
*/
refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec.url = (options?: RouteQueryOptions) => {
    return refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::refreshWorktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:854
* @route '/worktrees/refresh'
*/
refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::refreshWorktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:854
* @route '/environments/{environment}/worktrees/refresh'
*/
const refreshWorktrees18055fcf0ab3eb20b564818652ed440a = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refreshWorktrees18055fcf0ab3eb20b564818652ed440a.url(args, options),
    method: 'post',
})

refreshWorktrees18055fcf0ab3eb20b564818652ed440a.definition = {
    methods: ["post"],
    url: '/environments/{environment}/worktrees/refresh',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::refreshWorktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:854
* @route '/environments/{environment}/worktrees/refresh'
*/
refreshWorktrees18055fcf0ab3eb20b564818652ed440a.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return refreshWorktrees18055fcf0ab3eb20b564818652ed440a.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::refreshWorktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:854
* @route '/environments/{environment}/worktrees/refresh'
*/
refreshWorktrees18055fcf0ab3eb20b564818652ed440a.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: refreshWorktrees18055fcf0ab3eb20b564818652ed440a.url(args, options),
    method: 'post',
})

export const refreshWorktrees = {
    '/worktrees/refresh': refreshWorktrees59fd28a1bd7062a8448d0ae11ea7e2ec,
    '/environments/{environment}/worktrees/refresh': refreshWorktrees18055fcf0ab3eb20b564818652ed440a,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
const createSite21c9bad0ec8982d60785444156b0b402 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSite21c9bad0ec8982d60785444156b0b402.url(options),
    method: 'get',
})

createSite21c9bad0ec8982d60785444156b0b402.definition = {
    methods: ["get","head"],
    url: '/sites/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
createSite21c9bad0ec8982d60785444156b0b402.url = (options?: RouteQueryOptions) => {
    return createSite21c9bad0ec8982d60785444156b0b402.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
createSite21c9bad0ec8982d60785444156b0b402.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSite21c9bad0ec8982d60785444156b0b402.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
createSite21c9bad0ec8982d60785444156b0b402.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createSite21c9bad0ec8982d60785444156b0b402.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/projects/create'
*/
const createSite854856a96573f720f48e09da9946a4d0 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSite854856a96573f720f48e09da9946a4d0.url(options),
    method: 'get',
})

createSite854856a96573f720f48e09da9946a4d0.definition = {
    methods: ["get","head"],
    url: '/projects/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/projects/create'
*/
createSite854856a96573f720f48e09da9946a4d0.url = (options?: RouteQueryOptions) => {
    return createSite854856a96573f720f48e09da9946a4d0.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/projects/create'
*/
createSite854856a96573f720f48e09da9946a4d0.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSite854856a96573f720f48e09da9946a4d0.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/projects/create'
*/
createSite854856a96573f720f48e09da9946a4d0.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createSite854856a96573f720f48e09da9946a4d0.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
const createSitea21a59c360725133054c5e0fb59f2b06 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSitea21a59c360725133054c5e0fb59f2b06.url(args, options),
    method: 'get',
})

createSitea21a59c360725133054c5e0fb59f2b06.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
createSitea21a59c360725133054c5e0fb59f2b06.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return createSitea21a59c360725133054c5e0fb59f2b06.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
createSitea21a59c360725133054c5e0fb59f2b06.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSitea21a59c360725133054c5e0fb59f2b06.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
createSitea21a59c360725133054c5e0fb59f2b06.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createSitea21a59c360725133054c5e0fb59f2b06.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/projects/create'
*/
const createSite63f7db4c98e2f498ccff8efafe0b1515 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSite63f7db4c98e2f498ccff8efafe0b1515.url(args, options),
    method: 'get',
})

createSite63f7db4c98e2f498ccff8efafe0b1515.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/projects/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/projects/create'
*/
createSite63f7db4c98e2f498ccff8efafe0b1515.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return createSite63f7db4c98e2f498ccff8efafe0b1515.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/projects/create'
*/
createSite63f7db4c98e2f498ccff8efafe0b1515.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSite63f7db4c98e2f498ccff8efafe0b1515.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/projects/create'
*/
createSite63f7db4c98e2f498ccff8efafe0b1515.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createSite63f7db4c98e2f498ccff8efafe0b1515.url(args, options),
    method: 'head',
})

export const createSite = {
    '/sites/create': createSite21c9bad0ec8982d60785444156b0b402,
    '/projects/create': createSite854856a96573f720f48e09da9946a4d0,
    '/environments/{environment}/sites/create': createSitea21a59c360725133054c5e0fb59f2b06,
    '/environments/{environment}/projects/create': createSite63f7db4c98e2f498ccff8efafe0b1515,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/sites'
*/
const storeSitec5d66bd5c00172bfad72bf3878ac554b = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSitec5d66bd5c00172bfad72bf3878ac554b.url(options),
    method: 'post',
})

storeSitec5d66bd5c00172bfad72bf3878ac554b.definition = {
    methods: ["post"],
    url: '/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/sites'
*/
storeSitec5d66bd5c00172bfad72bf3878ac554b.url = (options?: RouteQueryOptions) => {
    return storeSitec5d66bd5c00172bfad72bf3878ac554b.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/sites'
*/
storeSitec5d66bd5c00172bfad72bf3878ac554b.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSitec5d66bd5c00172bfad72bf3878ac554b.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/projects'
*/
const storeSite8f35706c95c06c991312479b995e49d2 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite8f35706c95c06c991312479b995e49d2.url(options),
    method: 'post',
})

storeSite8f35706c95c06c991312479b995e49d2.definition = {
    methods: ["post"],
    url: '/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/projects'
*/
storeSite8f35706c95c06c991312479b995e49d2.url = (options?: RouteQueryOptions) => {
    return storeSite8f35706c95c06c991312479b995e49d2.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/projects'
*/
storeSite8f35706c95c06c991312479b995e49d2.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite8f35706c95c06c991312479b995e49d2.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/sites'
*/
const storeSitef1ae4f46fef3e725ed467b77218a7088 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSitef1ae4f46fef3e725ed467b77218a7088.url(args, options),
    method: 'post',
})

storeSitef1ae4f46fef3e725ed467b77218a7088.definition = {
    methods: ["post"],
    url: '/environments/{environment}/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/sites'
*/
storeSitef1ae4f46fef3e725ed467b77218a7088.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return storeSitef1ae4f46fef3e725ed467b77218a7088.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/sites'
*/
storeSitef1ae4f46fef3e725ed467b77218a7088.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSitef1ae4f46fef3e725ed467b77218a7088.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/projects'
*/
const storeSite13193bc4e7973307ae298f994b1e6878 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite13193bc4e7973307ae298f994b1e6878.url(args, options),
    method: 'post',
})

storeSite13193bc4e7973307ae298f994b1e6878.definition = {
    methods: ["post"],
    url: '/environments/{environment}/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/projects'
*/
storeSite13193bc4e7973307ae298f994b1e6878.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return storeSite13193bc4e7973307ae298f994b1e6878.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/projects'
*/
storeSite13193bc4e7973307ae298f994b1e6878.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite13193bc4e7973307ae298f994b1e6878.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/sites'
*/
const storeSite693618c018aaa2aa9672591ffdda4500 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite693618c018aaa2aa9672591ffdda4500.url(options),
    method: 'post',
})

storeSite693618c018aaa2aa9672591ffdda4500.definition = {
    methods: ["post"],
    url: '/api/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/sites'
*/
storeSite693618c018aaa2aa9672591ffdda4500.url = (options?: RouteQueryOptions) => {
    return storeSite693618c018aaa2aa9672591ffdda4500.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/sites'
*/
storeSite693618c018aaa2aa9672591ffdda4500.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite693618c018aaa2aa9672591ffdda4500.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/projects'
*/
const storeSite8b46e609ff6aa5711101f5859f1d83b4 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite8b46e609ff6aa5711101f5859f1d83b4.url(options),
    method: 'post',
})

storeSite8b46e609ff6aa5711101f5859f1d83b4.definition = {
    methods: ["post"],
    url: '/api/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/projects'
*/
storeSite8b46e609ff6aa5711101f5859f1d83b4.url = (options?: RouteQueryOptions) => {
    return storeSite8b46e609ff6aa5711101f5859f1d83b4.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/projects'
*/
storeSite8b46e609ff6aa5711101f5859f1d83b4.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSite8b46e609ff6aa5711101f5859f1d83b4.url(options),
    method: 'post',
})

export const storeSite = {
    '/sites': storeSitec5d66bd5c00172bfad72bf3878ac554b,
    '/projects': storeSite8f35706c95c06c991312479b995e49d2,
    '/environments/{environment}/sites': storeSitef1ae4f46fef3e725ed467b77218a7088,
    '/environments/{environment}/projects': storeSite13193bc4e7973307ae298f994b1e6878,
    '/api/sites': storeSite693618c018aaa2aa9672591ffdda4500,
    '/api/projects': storeSite8b46e609ff6aa5711101f5859f1d83b4,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/sites/{projectName}'
*/
const destroySitef1a839b6c5f014bb6463b7d335272b72 = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySitef1a839b6c5f014bb6463b7d335272b72.url(args, options),
    method: 'delete',
})

destroySitef1a839b6c5f014bb6463b7d335272b72.definition = {
    methods: ["delete"],
    url: '/sites/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/sites/{projectName}'
*/
destroySitef1a839b6c5f014bb6463b7d335272b72.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return destroySitef1a839b6c5f014bb6463b7d335272b72.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/sites/{projectName}'
*/
destroySitef1a839b6c5f014bb6463b7d335272b72.delete = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySitef1a839b6c5f014bb6463b7d335272b72.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/projects/{projectName}'
*/
const destroySitefb2cc8c0370968e427e4da0d0dc3d5ca = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySitefb2cc8c0370968e427e4da0d0dc3d5ca.url(args, options),
    method: 'delete',
})

destroySitefb2cc8c0370968e427e4da0d0dc3d5ca.definition = {
    methods: ["delete"],
    url: '/projects/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/projects/{projectName}'
*/
destroySitefb2cc8c0370968e427e4da0d0dc3d5ca.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return destroySitefb2cc8c0370968e427e4da0d0dc3d5ca.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/projects/{projectName}'
*/
destroySitefb2cc8c0370968e427e4da0d0dc3d5ca.delete = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySitefb2cc8c0370968e427e4da0d0dc3d5ca.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/sites/{projectName}'
*/
const destroySite84d305f54e13c5e7d623d233ae223ddc = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySite84d305f54e13c5e7d623d233ae223ddc.url(args, options),
    method: 'delete',
})

destroySite84d305f54e13c5e7d623d233ae223ddc.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/sites/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/sites/{projectName}'
*/
destroySite84d305f54e13c5e7d623d233ae223ddc.url = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectName: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectName: args.projectName,
    }

    return destroySite84d305f54e13c5e7d623d233ae223ddc.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/sites/{projectName}'
*/
destroySite84d305f54e13c5e7d623d233ae223ddc.delete = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySite84d305f54e13c5e7d623d233ae223ddc.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/projects/{projectName}'
*/
const destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670 = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670.url(args, options),
    method: 'delete',
})

destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/projects/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/projects/{projectName}'
*/
destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670.url = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectName: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectName: args.projectName,
    }

    return destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/projects/{projectName}'
*/
destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670.delete = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/sites/{projectName}'
*/
const destroySiteaa9e8f04d2248ef40711fbeb613c6151 = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySiteaa9e8f04d2248ef40711fbeb613c6151.url(args, options),
    method: 'delete',
})

destroySiteaa9e8f04d2248ef40711fbeb613c6151.definition = {
    methods: ["delete"],
    url: '/api/sites/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/sites/{projectName}'
*/
destroySiteaa9e8f04d2248ef40711fbeb613c6151.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return destroySiteaa9e8f04d2248ef40711fbeb613c6151.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/sites/{projectName}'
*/
destroySiteaa9e8f04d2248ef40711fbeb613c6151.delete = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySiteaa9e8f04d2248ef40711fbeb613c6151.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/projects/{projectName}'
*/
const destroySite040f6fe094a1ac3eadfe76ab9d2d9dac = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySite040f6fe094a1ac3eadfe76ab9d2d9dac.url(args, options),
    method: 'delete',
})

destroySite040f6fe094a1ac3eadfe76ab9d2d9dac.definition = {
    methods: ["delete"],
    url: '/api/projects/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/projects/{projectName}'
*/
destroySite040f6fe094a1ac3eadfe76ab9d2d9dac.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return destroySite040f6fe094a1ac3eadfe76ab9d2d9dac.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroySite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/projects/{projectName}'
*/
destroySite040f6fe094a1ac3eadfe76ab9d2d9dac.delete = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySite040f6fe094a1ac3eadfe76ab9d2d9dac.url(args, options),
    method: 'delete',
})

export const destroySite = {
    '/sites/{projectName}': destroySitef1a839b6c5f014bb6463b7d335272b72,
    '/projects/{projectName}': destroySitefb2cc8c0370968e427e4da0d0dc3d5ca,
    '/environments/{environment}/sites/{projectName}': destroySite84d305f54e13c5e7d623d233ae223ddc,
    '/environments/{environment}/projects/{projectName}': destroySiteb0dbeb7ecc2a57ac16290edd1bbd8670,
    '/api/sites/{projectName}': destroySiteaa9e8f04d2248ef40711fbeb613c6151,
    '/api/projects/{projectName}': destroySite040f6fe094a1ac3eadfe76ab9d2d9dac,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/sites/{projectName}/rebuild'
*/
const rebuildSited32331e4a089460214b0e8152fd9ffd7 = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSited32331e4a089460214b0e8152fd9ffd7.url(args, options),
    method: 'post',
})

rebuildSited32331e4a089460214b0e8152fd9ffd7.definition = {
    methods: ["post"],
    url: '/sites/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/sites/{projectName}/rebuild'
*/
rebuildSited32331e4a089460214b0e8152fd9ffd7.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return rebuildSited32331e4a089460214b0e8152fd9ffd7.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/sites/{projectName}/rebuild'
*/
rebuildSited32331e4a089460214b0e8152fd9ffd7.post = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSited32331e4a089460214b0e8152fd9ffd7.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/projects/{projectName}/rebuild'
*/
const rebuildSitea21962988e998dfc540416de94e2d060 = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSitea21962988e998dfc540416de94e2d060.url(args, options),
    method: 'post',
})

rebuildSitea21962988e998dfc540416de94e2d060.definition = {
    methods: ["post"],
    url: '/projects/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/projects/{projectName}/rebuild'
*/
rebuildSitea21962988e998dfc540416de94e2d060.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return rebuildSitea21962988e998dfc540416de94e2d060.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/projects/{projectName}/rebuild'
*/
rebuildSitea21962988e998dfc540416de94e2d060.post = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSitea21962988e998dfc540416de94e2d060.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/sites/{projectName}/rebuild'
*/
const rebuildSitebee19d83d0380745adb1e46e500fcbb2 = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSitebee19d83d0380745adb1e46e500fcbb2.url(args, options),
    method: 'post',
})

rebuildSitebee19d83d0380745adb1e46e500fcbb2.definition = {
    methods: ["post"],
    url: '/environments/{environment}/sites/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/sites/{projectName}/rebuild'
*/
rebuildSitebee19d83d0380745adb1e46e500fcbb2.url = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectName: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectName: args.projectName,
    }

    return rebuildSitebee19d83d0380745adb1e46e500fcbb2.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/sites/{projectName}/rebuild'
*/
rebuildSitebee19d83d0380745adb1e46e500fcbb2.post = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSitebee19d83d0380745adb1e46e500fcbb2.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/projects/{projectName}/rebuild'
*/
const rebuildSiteec070407e63e28a079e324e46a9bc437 = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSiteec070407e63e28a079e324e46a9bc437.url(args, options),
    method: 'post',
})

rebuildSiteec070407e63e28a079e324e46a9bc437.definition = {
    methods: ["post"],
    url: '/environments/{environment}/projects/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/projects/{projectName}/rebuild'
*/
rebuildSiteec070407e63e28a079e324e46a9bc437.url = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectName: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectName: args.projectName,
    }

    return rebuildSiteec070407e63e28a079e324e46a9bc437.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/projects/{projectName}/rebuild'
*/
rebuildSiteec070407e63e28a079e324e46a9bc437.post = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSiteec070407e63e28a079e324e46a9bc437.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/sites/{projectName}/rebuild'
*/
const rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba.url(args, options),
    method: 'post',
})

rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba.definition = {
    methods: ["post"],
    url: '/api/sites/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/sites/{projectName}/rebuild'
*/
rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/sites/{projectName}/rebuild'
*/
rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba.post = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/projects/{projectName}/rebuild'
*/
const rebuildSite83829fe93a13f689b4f9e687ebd32fdc = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSite83829fe93a13f689b4f9e687ebd32fdc.url(args, options),
    method: 'post',
})

rebuildSite83829fe93a13f689b4f9e687ebd32fdc.definition = {
    methods: ["post"],
    url: '/api/projects/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/projects/{projectName}/rebuild'
*/
rebuildSite83829fe93a13f689b4f9e687ebd32fdc.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return rebuildSite83829fe93a13f689b4f9e687ebd32fdc.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuildSite
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/projects/{projectName}/rebuild'
*/
rebuildSite83829fe93a13f689b4f9e687ebd32fdc.post = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuildSite83829fe93a13f689b4f9e687ebd32fdc.url(args, options),
    method: 'post',
})

export const rebuildSite = {
    '/sites/{projectName}/rebuild': rebuildSited32331e4a089460214b0e8152fd9ffd7,
    '/projects/{projectName}/rebuild': rebuildSitea21962988e998dfc540416de94e2d060,
    '/environments/{environment}/sites/{projectName}/rebuild': rebuildSitebee19d83d0380745adb1e46e500fcbb2,
    '/environments/{environment}/projects/{projectName}/rebuild': rebuildSiteec070407e63e28a079e324e46a9bc437,
    '/api/sites/{projectName}/rebuild': rebuildSitee83a1a7d382cdf64e640fc6d3e5008ba,
    '/api/projects/{projectName}/rebuild': rebuildSite83829fe93a13f689b4f9e687ebd32fdc,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
const provisionStatusb4728f4122760f643174133039476fbb = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatusb4728f4122760f643174133039476fbb.url(args, options),
    method: 'get',
})

provisionStatusb4728f4122760f643174133039476fbb.definition = {
    methods: ["get","head"],
    url: '/sites/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
provisionStatusb4728f4122760f643174133039476fbb.url = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectSlug: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectSlug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectSlug: args.projectSlug,
    }

    return provisionStatusb4728f4122760f643174133039476fbb.definition.url
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
provisionStatusb4728f4122760f643174133039476fbb.get = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatusb4728f4122760f643174133039476fbb.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
provisionStatusb4728f4122760f643174133039476fbb.head = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatusb4728f4122760f643174133039476fbb.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/projects/{projectSlug}/provision-status'
*/
const provisionStatus596e924109ecdca406b7ba98b85b961b = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus596e924109ecdca406b7ba98b85b961b.url(args, options),
    method: 'get',
})

provisionStatus596e924109ecdca406b7ba98b85b961b.definition = {
    methods: ["get","head"],
    url: '/projects/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/projects/{projectSlug}/provision-status'
*/
provisionStatus596e924109ecdca406b7ba98b85b961b.url = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectSlug: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectSlug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectSlug: args.projectSlug,
    }

    return provisionStatus596e924109ecdca406b7ba98b85b961b.definition.url
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/projects/{projectSlug}/provision-status'
*/
provisionStatus596e924109ecdca406b7ba98b85b961b.get = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus596e924109ecdca406b7ba98b85b961b.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/projects/{projectSlug}/provision-status'
*/
provisionStatus596e924109ecdca406b7ba98b85b961b.head = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatus596e924109ecdca406b7ba98b85b961b.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
const provisionStatus6f84a033ab5b373936da3bde0e39a07c = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus6f84a033ab5b373936da3bde0e39a07c.url(args, options),
    method: 'get',
})

provisionStatus6f84a033ab5b373936da3bde0e39a07c.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
provisionStatus6f84a033ab5b373936da3bde0e39a07c.url = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectSlug: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectSlug: args.projectSlug,
    }

    return provisionStatus6f84a033ab5b373936da3bde0e39a07c.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
provisionStatus6f84a033ab5b373936da3bde0e39a07c.get = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus6f84a033ab5b373936da3bde0e39a07c.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
provisionStatus6f84a033ab5b373936da3bde0e39a07c.head = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatus6f84a033ab5b373936da3bde0e39a07c.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/projects/{projectSlug}/provision-status'
*/
const provisionStatusc621db1108bba79aeb9964b699a6556f = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatusc621db1108bba79aeb9964b699a6556f.url(args, options),
    method: 'get',
})

provisionStatusc621db1108bba79aeb9964b699a6556f.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/projects/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/projects/{projectSlug}/provision-status'
*/
provisionStatusc621db1108bba79aeb9964b699a6556f.url = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectSlug: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectSlug: args.projectSlug,
    }

    return provisionStatusc621db1108bba79aeb9964b699a6556f.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/projects/{projectSlug}/provision-status'
*/
provisionStatusc621db1108bba79aeb9964b699a6556f.get = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatusc621db1108bba79aeb9964b699a6556f.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/projects/{projectSlug}/provision-status'
*/
provisionStatusc621db1108bba79aeb9964b699a6556f.head = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatusc621db1108bba79aeb9964b699a6556f.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
const provisionStatuse8e54d3f413319c6fc09b2b22a379ac5 = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.url(args, options),
    method: 'get',
})

provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.definition = {
    methods: ["get","head"],
    url: '/api/sites/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.url = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectSlug: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectSlug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectSlug: args.projectSlug,
    }

    return provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.definition.url
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.get = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.head = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatuse8e54d3f413319c6fc09b2b22a379ac5.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/projects/{projectSlug}/provision-status'
*/
const provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2 = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.url(args, options),
    method: 'get',
})

provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.definition = {
    methods: ["get","head"],
    url: '/api/projects/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/projects/{projectSlug}/provision-status'
*/
provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.url = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectSlug: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectSlug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectSlug: args.projectSlug,
    }

    return provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.definition.url
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/projects/{projectSlug}/provision-status'
*/
provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.get = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/projects/{projectSlug}/provision-status'
*/
provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.head = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2.url(args, options),
    method: 'head',
})

export const provisionStatus = {
    '/sites/{projectSlug}/provision-status': provisionStatusb4728f4122760f643174133039476fbb,
    '/projects/{projectSlug}/provision-status': provisionStatus596e924109ecdca406b7ba98b85b961b,
    '/environments/{environment}/sites/{projectSlug}/provision-status': provisionStatus6f84a033ab5b373936da3bde0e39a07c,
    '/environments/{environment}/projects/{projectSlug}/provision-status': provisionStatusc621db1108bba79aeb9964b699a6556f,
    '/api/sites/{projectSlug}/provision-status': provisionStatuse8e54d3f413319c6fc09b2b22a379ac5,
    '/api/projects/{projectSlug}/provision-status': provisionStatus55ebc6cbdadb70ef3c2bfeed3fba46a2,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/template-defaults'
*/
const templateDefaults44ee93d7b29fd22d66db33ad59335197 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults44ee93d7b29fd22d66db33ad59335197.url(options),
    method: 'post',
})

templateDefaults44ee93d7b29fd22d66db33ad59335197.definition = {
    methods: ["post"],
    url: '/template-defaults',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/template-defaults'
*/
templateDefaults44ee93d7b29fd22d66db33ad59335197.url = (options?: RouteQueryOptions) => {
    return templateDefaults44ee93d7b29fd22d66db33ad59335197.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/template-defaults'
*/
templateDefaults44ee93d7b29fd22d66db33ad59335197.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults44ee93d7b29fd22d66db33ad59335197.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/environments/{environment}/template-defaults'
*/
const templateDefaults83f69783fa123da9d9e97d3583ec4434 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults83f69783fa123da9d9e97d3583ec4434.url(args, options),
    method: 'post',
})

templateDefaults83f69783fa123da9d9e97d3583ec4434.definition = {
    methods: ["post"],
    url: '/environments/{environment}/template-defaults',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/environments/{environment}/template-defaults'
*/
templateDefaults83f69783fa123da9d9e97d3583ec4434.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return templateDefaults83f69783fa123da9d9e97d3583ec4434.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/environments/{environment}/template-defaults'
*/
templateDefaults83f69783fa123da9d9e97d3583ec4434.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults83f69783fa123da9d9e97d3583ec4434.url(args, options),
    method: 'post',
})

export const templateDefaults = {
    '/template-defaults': templateDefaults44ee93d7b29fd22d66db33ad59335197,
    '/environments/{environment}/template-defaults': templateDefaults83f69783fa123da9d9e97d3583ec4434,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
const githubUser560a820a7df6548795ec89cd74f7433f = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser560a820a7df6548795ec89cd74f7433f.url(options),
    method: 'get',
})

githubUser560a820a7df6548795ec89cd74f7433f.definition = {
    methods: ["get","head"],
    url: '/github-user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
githubUser560a820a7df6548795ec89cd74f7433f.url = (options?: RouteQueryOptions) => {
    return githubUser560a820a7df6548795ec89cd74f7433f.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
githubUser560a820a7df6548795ec89cd74f7433f.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser560a820a7df6548795ec89cd74f7433f.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
githubUser560a820a7df6548795ec89cd74f7433f.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubUser560a820a7df6548795ec89cd74f7433f.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
const githubUser9943bcabe98a8ec68cc22edb5b096eaa = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser9943bcabe98a8ec68cc22edb5b096eaa.url(args, options),
    method: 'get',
})

githubUser9943bcabe98a8ec68cc22edb5b096eaa.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/github-user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
githubUser9943bcabe98a8ec68cc22edb5b096eaa.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return githubUser9943bcabe98a8ec68cc22edb5b096eaa.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
githubUser9943bcabe98a8ec68cc22edb5b096eaa.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser9943bcabe98a8ec68cc22edb5b096eaa.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
githubUser9943bcabe98a8ec68cc22edb5b096eaa.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubUser9943bcabe98a8ec68cc22edb5b096eaa.url(args, options),
    method: 'head',
})

export const githubUser = {
    '/github-user': githubUser560a820a7df6548795ec89cd74f7433f,
    '/environments/{environment}/github-user': githubUser9943bcabe98a8ec68cc22edb5b096eaa,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
const githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.url(options),
    method: 'get',
})

githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.definition = {
    methods: ["get","head"],
    url: '/github-orgs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.url = (options?: RouteQueryOptions) => {
    return githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
const githubOrgs0384f96c6ecb22ee259bcb338a5479dd = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgs0384f96c6ecb22ee259bcb338a5479dd.url(args, options),
    method: 'get',
})

githubOrgs0384f96c6ecb22ee259bcb338a5479dd.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/github-orgs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
githubOrgs0384f96c6ecb22ee259bcb338a5479dd.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return githubOrgs0384f96c6ecb22ee259bcb338a5479dd.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
githubOrgs0384f96c6ecb22ee259bcb338a5479dd.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgs0384f96c6ecb22ee259bcb338a5479dd.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
githubOrgs0384f96c6ecb22ee259bcb338a5479dd.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubOrgs0384f96c6ecb22ee259bcb338a5479dd.url(args, options),
    method: 'head',
})

export const githubOrgs = {
    '/github-orgs': githubOrgse4a4ba1c12edda3fd4a1c7ee5fd1a5e0,
    '/environments/{environment}/github-orgs': githubOrgs0384f96c6ecb22ee259bcb338a5479dd,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/github-repo-exists'
*/
const githubRepoExists1ddafaefbfb4958048b15db261258d43 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExists1ddafaefbfb4958048b15db261258d43.url(options),
    method: 'post',
})

githubRepoExists1ddafaefbfb4958048b15db261258d43.definition = {
    methods: ["post"],
    url: '/github-repo-exists',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/github-repo-exists'
*/
githubRepoExists1ddafaefbfb4958048b15db261258d43.url = (options?: RouteQueryOptions) => {
    return githubRepoExists1ddafaefbfb4958048b15db261258d43.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/github-repo-exists'
*/
githubRepoExists1ddafaefbfb4958048b15db261258d43.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExists1ddafaefbfb4958048b15db261258d43.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/environments/{environment}/github-repo-exists'
*/
const githubRepoExistsefe221800d02fd9a42bc5a988a05046c = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExistsefe221800d02fd9a42bc5a988a05046c.url(args, options),
    method: 'post',
})

githubRepoExistsefe221800d02fd9a42bc5a988a05046c.definition = {
    methods: ["post"],
    url: '/environments/{environment}/github-repo-exists',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/environments/{environment}/github-repo-exists'
*/
githubRepoExistsefe221800d02fd9a42bc5a988a05046c.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return githubRepoExistsefe221800d02fd9a42bc5a988a05046c.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/environments/{environment}/github-repo-exists'
*/
githubRepoExistsefe221800d02fd9a42bc5a988a05046c.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExistsefe221800d02fd9a42bc5a988a05046c.url(args, options),
    method: 'post',
})

export const githubRepoExists = {
    '/github-repo-exists': githubRepoExists1ddafaefbfb4958048b15db261258d43,
    '/environments/{environment}/github-repo-exists': githubRepoExistsefe221800d02fd9a42bc5a988a05046c,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
const linearTeams65cbf4adbd16010046b9ac6f95144a83 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams65cbf4adbd16010046b9ac6f95144a83.url(options),
    method: 'get',
})

linearTeams65cbf4adbd16010046b9ac6f95144a83.definition = {
    methods: ["get","head"],
    url: '/linear-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
linearTeams65cbf4adbd16010046b9ac6f95144a83.url = (options?: RouteQueryOptions) => {
    return linearTeams65cbf4adbd16010046b9ac6f95144a83.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
linearTeams65cbf4adbd16010046b9ac6f95144a83.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams65cbf4adbd16010046b9ac6f95144a83.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
linearTeams65cbf4adbd16010046b9ac6f95144a83.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linearTeams65cbf4adbd16010046b9ac6f95144a83.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
const linearTeams008a76d8bb91ec775c3466dc7e0fc65b = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams008a76d8bb91ec775c3466dc7e0fc65b.url(args, options),
    method: 'get',
})

linearTeams008a76d8bb91ec775c3466dc7e0fc65b.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/linear-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
linearTeams008a76d8bb91ec775c3466dc7e0fc65b.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return linearTeams008a76d8bb91ec775c3466dc7e0fc65b.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
linearTeams008a76d8bb91ec775c3466dc7e0fc65b.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams008a76d8bb91ec775c3466dc7e0fc65b.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
linearTeams008a76d8bb91ec775c3466dc7e0fc65b.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linearTeams008a76d8bb91ec775c3466dc7e0fc65b.url(args, options),
    method: 'head',
})

export const linearTeams = {
    '/linear-teams': linearTeams65cbf4adbd16010046b9ac6f95144a83,
    '/environments/{environment}/linear-teams': linearTeams008a76d8bb91ec775c3466dc7e0fc65b,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
const workspaces537873f44a81aa8f3de3521a29cb8807 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces537873f44a81aa8f3de3521a29cb8807.url(options),
    method: 'get',
})

workspaces537873f44a81aa8f3de3521a29cb8807.definition = {
    methods: ["get","head"],
    url: '/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
workspaces537873f44a81aa8f3de3521a29cb8807.url = (options?: RouteQueryOptions) => {
    return workspaces537873f44a81aa8f3de3521a29cb8807.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
workspaces537873f44a81aa8f3de3521a29cb8807.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces537873f44a81aa8f3de3521a29cb8807.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
workspaces537873f44a81aa8f3de3521a29cb8807.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspaces537873f44a81aa8f3de3521a29cb8807.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
const workspaces553f11785fd359f1b61f9b6da24a9144 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces553f11785fd359f1b61f9b6da24a9144.url(args, options),
    method: 'get',
})

workspaces553f11785fd359f1b61f9b6da24a9144.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
workspaces553f11785fd359f1b61f9b6da24a9144.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return workspaces553f11785fd359f1b61f9b6da24a9144.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
workspaces553f11785fd359f1b61f9b6da24a9144.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces553f11785fd359f1b61f9b6da24a9144.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
workspaces553f11785fd359f1b61f9b6da24a9144.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspaces553f11785fd359f1b61f9b6da24a9144.url(args, options),
    method: 'head',
})

export const workspaces = {
    '/workspaces': workspaces537873f44a81aa8f3de3521a29cb8807,
    '/environments/{environment}/workspaces': workspaces553f11785fd359f1b61f9b6da24a9144,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/workspaces/create'
*/
const createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.url(options),
    method: 'get',
})

createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.definition = {
    methods: ["get","head"],
    url: '/workspaces/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/workspaces/create'
*/
createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.url = (options?: RouteQueryOptions) => {
    return createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/workspaces/create'
*/
createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/workspaces/create'
*/
createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/environments/{environment}/workspaces/create'
*/
const createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.url(args, options),
    method: 'get',
})

createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/workspaces/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/environments/{environment}/workspaces/create'
*/
createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/environments/{environment}/workspaces/create'
*/
createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::createWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1362
* @route '/environments/{environment}/workspaces/create'
*/
createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8.url(args, options),
    method: 'head',
})

export const createWorkspace = {
    '/workspaces/create': createWorkspace7356ccd77f515c30ebb251eaa6f3cd9a,
    '/environments/{environment}/workspaces/create': createWorkspaceb3bd4b15ff00a2464250b7235f7e05d8,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1372
* @route '/workspaces'
*/
const storeWorkspace537873f44a81aa8f3de3521a29cb8807 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeWorkspace537873f44a81aa8f3de3521a29cb8807.url(options),
    method: 'post',
})

storeWorkspace537873f44a81aa8f3de3521a29cb8807.definition = {
    methods: ["post"],
    url: '/workspaces',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1372
* @route '/workspaces'
*/
storeWorkspace537873f44a81aa8f3de3521a29cb8807.url = (options?: RouteQueryOptions) => {
    return storeWorkspace537873f44a81aa8f3de3521a29cb8807.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1372
* @route '/workspaces'
*/
storeWorkspace537873f44a81aa8f3de3521a29cb8807.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeWorkspace537873f44a81aa8f3de3521a29cb8807.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1372
* @route '/environments/{environment}/workspaces'
*/
const storeWorkspace553f11785fd359f1b61f9b6da24a9144 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeWorkspace553f11785fd359f1b61f9b6da24a9144.url(args, options),
    method: 'post',
})

storeWorkspace553f11785fd359f1b61f9b6da24a9144.definition = {
    methods: ["post"],
    url: '/environments/{environment}/workspaces',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1372
* @route '/environments/{environment}/workspaces'
*/
storeWorkspace553f11785fd359f1b61f9b6da24a9144.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return storeWorkspace553f11785fd359f1b61f9b6da24a9144.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::storeWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1372
* @route '/environments/{environment}/workspaces'
*/
storeWorkspace553f11785fd359f1b61f9b6da24a9144.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeWorkspace553f11785fd359f1b61f9b6da24a9144.url(args, options),
    method: 'post',
})

export const storeWorkspace = {
    '/workspaces': storeWorkspace537873f44a81aa8f3de3521a29cb8807,
    '/environments/{environment}/workspaces': storeWorkspace553f11785fd359f1b61f9b6da24a9144,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/workspaces/{workspace}'
*/
const showWorkspace271939dd8732504f7cd34c1d4ba099a9 = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showWorkspace271939dd8732504f7cd34c1d4ba099a9.url(args, options),
    method: 'get',
})

showWorkspace271939dd8732504f7cd34c1d4ba099a9.definition = {
    methods: ["get","head"],
    url: '/workspaces/{workspace}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/workspaces/{workspace}'
*/
showWorkspace271939dd8732504f7cd34c1d4ba099a9.url = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workspace: args }
    }

    if (Array.isArray(args)) {
        args = {
            workspace: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workspace: args.workspace,
    }

    return showWorkspace271939dd8732504f7cd34c1d4ba099a9.definition.url
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/workspaces/{workspace}'
*/
showWorkspace271939dd8732504f7cd34c1d4ba099a9.get = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showWorkspace271939dd8732504f7cd34c1d4ba099a9.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/workspaces/{workspace}'
*/
showWorkspace271939dd8732504f7cd34c1d4ba099a9.head = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showWorkspace271939dd8732504f7cd34c1d4ba099a9.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/environments/{environment}/workspaces/{workspace}'
*/
const showWorkspace17418420c6da3f80aacfc17e07f04db5 = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showWorkspace17418420c6da3f80aacfc17e07f04db5.url(args, options),
    method: 'get',
})

showWorkspace17418420c6da3f80aacfc17e07f04db5.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/workspaces/{workspace}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/environments/{environment}/workspaces/{workspace}'
*/
showWorkspace17418420c6da3f80aacfc17e07f04db5.url = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
    }

    return showWorkspace17418420c6da3f80aacfc17e07f04db5.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/environments/{environment}/workspaces/{workspace}'
*/
showWorkspace17418420c6da3f80aacfc17e07f04db5.get = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showWorkspace17418420c6da3f80aacfc17e07f04db5.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::showWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1391
* @route '/environments/{environment}/workspaces/{workspace}'
*/
showWorkspace17418420c6da3f80aacfc17e07f04db5.head = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showWorkspace17418420c6da3f80aacfc17e07f04db5.url(args, options),
    method: 'head',
})

export const showWorkspace = {
    '/workspaces/{workspace}': showWorkspace271939dd8732504f7cd34c1d4ba099a9,
    '/environments/{environment}/workspaces/{workspace}': showWorkspace17418420c6da3f80aacfc17e07f04db5,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroyWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1431
* @route '/workspaces/{workspace}'
*/
const destroyWorkspace271939dd8732504f7cd34c1d4ba099a9 = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyWorkspace271939dd8732504f7cd34c1d4ba099a9.url(args, options),
    method: 'delete',
})

destroyWorkspace271939dd8732504f7cd34c1d4ba099a9.definition = {
    methods: ["delete"],
    url: '/workspaces/{workspace}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroyWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1431
* @route '/workspaces/{workspace}'
*/
destroyWorkspace271939dd8732504f7cd34c1d4ba099a9.url = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workspace: args }
    }

    if (Array.isArray(args)) {
        args = {
            workspace: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workspace: args.workspace,
    }

    return destroyWorkspace271939dd8732504f7cd34c1d4ba099a9.definition.url
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroyWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1431
* @route '/workspaces/{workspace}'
*/
destroyWorkspace271939dd8732504f7cd34c1d4ba099a9.delete = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyWorkspace271939dd8732504f7cd34c1d4ba099a9.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroyWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1431
* @route '/environments/{environment}/workspaces/{workspace}'
*/
const destroyWorkspace17418420c6da3f80aacfc17e07f04db5 = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyWorkspace17418420c6da3f80aacfc17e07f04db5.url(args, options),
    method: 'delete',
})

destroyWorkspace17418420c6da3f80aacfc17e07f04db5.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/workspaces/{workspace}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroyWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1431
* @route '/environments/{environment}/workspaces/{workspace}'
*/
destroyWorkspace17418420c6da3f80aacfc17e07f04db5.url = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
    }

    return destroyWorkspace17418420c6da3f80aacfc17e07f04db5.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroyWorkspace
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1431
* @route '/environments/{environment}/workspaces/{workspace}'
*/
destroyWorkspace17418420c6da3f80aacfc17e07f04db5.delete = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyWorkspace17418420c6da3f80aacfc17e07f04db5.url(args, options),
    method: 'delete',
})

export const destroyWorkspace = {
    '/workspaces/{workspace}': destroyWorkspace271939dd8732504f7cd34c1d4ba099a9,
    '/environments/{environment}/workspaces/{workspace}': destroyWorkspace17418420c6da3f80aacfc17e07f04db5,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/workspaces/{workspace}/sites'
*/
const addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378 = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378.url(args, options),
    method: 'post',
})

addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378.definition = {
    methods: ["post"],
    url: '/workspaces/{workspace}/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/workspaces/{workspace}/sites'
*/
addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378.url = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workspace: args }
    }

    if (Array.isArray(args)) {
        args = {
            workspace: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workspace: args.workspace,
    }

    return addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378.definition.url
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/workspaces/{workspace}/sites'
*/
addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378.post = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/workspaces/{workspace}/projects'
*/
const addWorkspaceProject508d544717bfe42359adae57548617ae = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject508d544717bfe42359adae57548617ae.url(args, options),
    method: 'post',
})

addWorkspaceProject508d544717bfe42359adae57548617ae.definition = {
    methods: ["post"],
    url: '/workspaces/{workspace}/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/workspaces/{workspace}/projects'
*/
addWorkspaceProject508d544717bfe42359adae57548617ae.url = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { workspace: args }
    }

    if (Array.isArray(args)) {
        args = {
            workspace: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workspace: args.workspace,
    }

    return addWorkspaceProject508d544717bfe42359adae57548617ae.definition.url
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/workspaces/{workspace}/projects'
*/
addWorkspaceProject508d544717bfe42359adae57548617ae.post = (args: { workspace: string | number } | [workspace: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject508d544717bfe42359adae57548617ae.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/environments/{environment}/workspaces/{workspace}/sites'
*/
const addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b.url(args, options),
    method: 'post',
})

addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b.definition = {
    methods: ["post"],
    url: '/environments/{environment}/workspaces/{workspace}/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/environments/{environment}/workspaces/{workspace}/sites'
*/
addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b.url = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
    }

    return addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/environments/{environment}/workspaces/{workspace}/sites'
*/
addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b.post = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/environments/{environment}/workspaces/{workspace}/projects'
*/
const addWorkspaceProject69668cd79dea102eaabc6a68c22391a7 = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject69668cd79dea102eaabc6a68c22391a7.url(args, options),
    method: 'post',
})

addWorkspaceProject69668cd79dea102eaabc6a68c22391a7.definition = {
    methods: ["post"],
    url: '/environments/{environment}/workspaces/{workspace}/projects',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/environments/{environment}/workspaces/{workspace}/projects'
*/
addWorkspaceProject69668cd79dea102eaabc6a68c22391a7.url = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
    }

    return addWorkspaceProject69668cd79dea102eaabc6a68c22391a7.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::addWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1446
* @route '/environments/{environment}/workspaces/{workspace}/projects'
*/
addWorkspaceProject69668cd79dea102eaabc6a68c22391a7.post = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addWorkspaceProject69668cd79dea102eaabc6a68c22391a7.url(args, options),
    method: 'post',
})

export const addWorkspaceProject = {
    '/workspaces/{workspace}/sites': addWorkspaceProject90dc98a40f230a97e59b3b4198bb5378,
    '/workspaces/{workspace}/projects': addWorkspaceProject508d544717bfe42359adae57548617ae,
    '/environments/{environment}/workspaces/{workspace}/sites': addWorkspaceProject6439c06f2977a0d7ddbe0c9b491a465b,
    '/environments/{environment}/workspaces/{workspace}/projects': addWorkspaceProject69668cd79dea102eaabc6a68c22391a7,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/workspaces/{workspace}/sites/{project}'
*/
const removeWorkspaceProject9a068e3f4e50104c332a89239f92182f = (args: { workspace: string | number, project: string | number } | [workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProject9a068e3f4e50104c332a89239f92182f.url(args, options),
    method: 'delete',
})

removeWorkspaceProject9a068e3f4e50104c332a89239f92182f.definition = {
    methods: ["delete"],
    url: '/workspaces/{workspace}/sites/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/workspaces/{workspace}/sites/{project}'
*/
removeWorkspaceProject9a068e3f4e50104c332a89239f92182f.url = (args: { workspace: string | number, project: string | number } | [workspace: string | number, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            workspace: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workspace: args.workspace,
        project: args.project,
    }

    return removeWorkspaceProject9a068e3f4e50104c332a89239f92182f.definition.url
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/workspaces/{workspace}/sites/{project}'
*/
removeWorkspaceProject9a068e3f4e50104c332a89239f92182f.delete = (args: { workspace: string | number, project: string | number } | [workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProject9a068e3f4e50104c332a89239f92182f.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/workspaces/{workspace}/projects/{project}'
*/
const removeWorkspaceProject4412581e05ee697a0ef73373de4c465a = (args: { workspace: string | number, project: string | number } | [workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProject4412581e05ee697a0ef73373de4c465a.url(args, options),
    method: 'delete',
})

removeWorkspaceProject4412581e05ee697a0ef73373de4c465a.definition = {
    methods: ["delete"],
    url: '/workspaces/{workspace}/projects/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/workspaces/{workspace}/projects/{project}'
*/
removeWorkspaceProject4412581e05ee697a0ef73373de4c465a.url = (args: { workspace: string | number, project: string | number } | [workspace: string | number, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            workspace: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        workspace: args.workspace,
        project: args.project,
    }

    return removeWorkspaceProject4412581e05ee697a0ef73373de4c465a.definition.url
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/workspaces/{workspace}/projects/{project}'
*/
removeWorkspaceProject4412581e05ee697a0ef73373de4c465a.delete = (args: { workspace: string | number, project: string | number } | [workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProject4412581e05ee697a0ef73373de4c465a.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/environments/{environment}/workspaces/{workspace}/sites/{project}'
*/
const removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b = (args: { environment: number | { id: number }, workspace: string | number, project: string | number } | [environment: number | { id: number }, workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b.url(args, options),
    method: 'delete',
})

removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/workspaces/{workspace}/sites/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/environments/{environment}/workspaces/{workspace}/sites/{project}'
*/
removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b.url = (args: { environment: number | { id: number }, workspace: string | number, project: string | number } | [environment: number | { id: number }, workspace: string | number, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
            project: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
        project: args.project,
    }

    return removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/environments/{environment}/workspaces/{workspace}/sites/{project}'
*/
removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b.delete = (args: { environment: number | { id: number }, workspace: string | number, project: string | number } | [environment: number | { id: number }, workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/environments/{environment}/workspaces/{workspace}/projects/{project}'
*/
const removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8 = (args: { environment: number | { id: number }, workspace: string | number, project: string | number } | [environment: number | { id: number }, workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8.url(args, options),
    method: 'delete',
})

removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/workspaces/{workspace}/projects/{project}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/environments/{environment}/workspaces/{workspace}/projects/{project}'
*/
removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8.url = (args: { environment: number | { id: number }, workspace: string | number, project: string | number } | [environment: number | { id: number }, workspace: string | number, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
            project: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
        project: args.project,
    }

    return removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::removeWorkspaceProject
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1470
* @route '/environments/{environment}/workspaces/{workspace}/projects/{project}'
*/
removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8.delete = (args: { environment: number | { id: number }, workspace: string | number, project: string | number } | [environment: number | { id: number }, workspace: string | number, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8.url(args, options),
    method: 'delete',
})

export const removeWorkspaceProject = {
    '/workspaces/{workspace}/sites/{project}': removeWorkspaceProject9a068e3f4e50104c332a89239f92182f,
    '/workspaces/{workspace}/projects/{project}': removeWorkspaceProject4412581e05ee697a0ef73373de4c465a,
    '/environments/{environment}/workspaces/{workspace}/sites/{project}': removeWorkspaceProjectd04c2cd79f159d0a07df5b4cc7efde8b,
    '/environments/{environment}/workspaces/{workspace}/projects/{project}': removeWorkspaceProject321abeb727ddec565135b1866bdfa1d8,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
const linkedPackages0432019ec070ed0a8cec1e4554bd33db = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages0432019ec070ed0a8cec1e4554bd33db.url(args, options),
    method: 'get',
})

linkedPackages0432019ec070ed0a8cec1e4554bd33db.definition = {
    methods: ["get","head"],
    url: '/sites/{project}/linked-packages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
linkedPackages0432019ec070ed0a8cec1e4554bd33db.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
    }

    return linkedPackages0432019ec070ed0a8cec1e4554bd33db.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
linkedPackages0432019ec070ed0a8cec1e4554bd33db.get = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages0432019ec070ed0a8cec1e4554bd33db.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
linkedPackages0432019ec070ed0a8cec1e4554bd33db.head = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linkedPackages0432019ec070ed0a8cec1e4554bd33db.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/projects/{project}/linked-packages'
*/
const linkedPackagesed2d34ec643aeb262610c7c2e932d5f9 = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.url(args, options),
    method: 'get',
})

linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.definition = {
    methods: ["get","head"],
    url: '/projects/{project}/linked-packages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/projects/{project}/linked-packages'
*/
linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
    }

    return linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/projects/{project}/linked-packages'
*/
linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.get = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/projects/{project}/linked-packages'
*/
linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.head = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linkedPackagesed2d34ec643aeb262610c7c2e932d5f9.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
const linkedPackages25a2ebd3eed6b1a28393b0169725e218 = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages25a2ebd3eed6b1a28393b0169725e218.url(args, options),
    method: 'get',
})

linkedPackages25a2ebd3eed6b1a28393b0169725e218.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites/{project}/linked-packages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
linkedPackages25a2ebd3eed6b1a28393b0169725e218.url = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
    }

    return linkedPackages25a2ebd3eed6b1a28393b0169725e218.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
linkedPackages25a2ebd3eed6b1a28393b0169725e218.get = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages25a2ebd3eed6b1a28393b0169725e218.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
linkedPackages25a2ebd3eed6b1a28393b0169725e218.head = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linkedPackages25a2ebd3eed6b1a28393b0169725e218.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/projects/{project}/linked-packages'
*/
const linkedPackages7975f324c82c7d8bdbdd28d53f7ab339 = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.url(args, options),
    method: 'get',
})

linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/projects/{project}/linked-packages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/projects/{project}/linked-packages'
*/
linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.url = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
    }

    return linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/projects/{project}/linked-packages'
*/
linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.get = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/projects/{project}/linked-packages'
*/
linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.head = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linkedPackages7975f324c82c7d8bdbdd28d53f7ab339.url(args, options),
    method: 'head',
})

export const linkedPackages = {
    '/sites/{project}/linked-packages': linkedPackages0432019ec070ed0a8cec1e4554bd33db,
    '/projects/{project}/linked-packages': linkedPackagesed2d34ec643aeb262610c7c2e932d5f9,
    '/environments/{environment}/sites/{project}/linked-packages': linkedPackages25a2ebd3eed6b1a28393b0169725e218,
    '/environments/{environment}/projects/{project}/linked-packages': linkedPackages7975f324c82c7d8bdbdd28d53f7ab339,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/sites/{project}/link-package'
*/
const linkPackagee07dad949dcd8355ed5367e5925214ec = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackagee07dad949dcd8355ed5367e5925214ec.url(args, options),
    method: 'post',
})

linkPackagee07dad949dcd8355ed5367e5925214ec.definition = {
    methods: ["post"],
    url: '/sites/{project}/link-package',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/sites/{project}/link-package'
*/
linkPackagee07dad949dcd8355ed5367e5925214ec.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
    }

    return linkPackagee07dad949dcd8355ed5367e5925214ec.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/sites/{project}/link-package'
*/
linkPackagee07dad949dcd8355ed5367e5925214ec.post = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackagee07dad949dcd8355ed5367e5925214ec.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/projects/{project}/link-package'
*/
const linkPackagef5cb1652db663173a9626ea4c633b92c = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackagef5cb1652db663173a9626ea4c633b92c.url(args, options),
    method: 'post',
})

linkPackagef5cb1652db663173a9626ea4c633b92c.definition = {
    methods: ["post"],
    url: '/projects/{project}/link-package',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/projects/{project}/link-package'
*/
linkPackagef5cb1652db663173a9626ea4c633b92c.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
    }

    return linkPackagef5cb1652db663173a9626ea4c633b92c.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/projects/{project}/link-package'
*/
linkPackagef5cb1652db663173a9626ea4c633b92c.post = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackagef5cb1652db663173a9626ea4c633b92c.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/sites/{project}/link-package'
*/
const linkPackage4377744debd340b59eaf1a9c8aec7dde = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage4377744debd340b59eaf1a9c8aec7dde.url(args, options),
    method: 'post',
})

linkPackage4377744debd340b59eaf1a9c8aec7dde.definition = {
    methods: ["post"],
    url: '/environments/{environment}/sites/{project}/link-package',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/sites/{project}/link-package'
*/
linkPackage4377744debd340b59eaf1a9c8aec7dde.url = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
    }

    return linkPackage4377744debd340b59eaf1a9c8aec7dde.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/sites/{project}/link-package'
*/
linkPackage4377744debd340b59eaf1a9c8aec7dde.post = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage4377744debd340b59eaf1a9c8aec7dde.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/projects/{project}/link-package'
*/
const linkPackage5e678029c382095c0af7f79102a4b5de = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage5e678029c382095c0af7f79102a4b5de.url(args, options),
    method: 'post',
})

linkPackage5e678029c382095c0af7f79102a4b5de.definition = {
    methods: ["post"],
    url: '/environments/{environment}/projects/{project}/link-package',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/projects/{project}/link-package'
*/
linkPackage5e678029c382095c0af7f79102a4b5de.url = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
    }

    return linkPackage5e678029c382095c0af7f79102a4b5de.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/projects/{project}/link-package'
*/
linkPackage5e678029c382095c0af7f79102a4b5de.post = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage5e678029c382095c0af7f79102a4b5de.url(args, options),
    method: 'post',
})

export const linkPackage = {
    '/sites/{project}/link-package': linkPackagee07dad949dcd8355ed5367e5925214ec,
    '/projects/{project}/link-package': linkPackagef5cb1652db663173a9626ea4c633b92c,
    '/environments/{environment}/sites/{project}/link-package': linkPackage4377744debd340b59eaf1a9c8aec7dde,
    '/environments/{environment}/projects/{project}/link-package': linkPackage5e678029c382095c0af7f79102a4b5de,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/sites/{project}/unlink-package/{package}'
*/
const unlinkPackagece8c9f497fa17b03515c96f09f0e25d6 = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackagece8c9f497fa17b03515c96f09f0e25d6.url(args, options),
    method: 'delete',
})

unlinkPackagece8c9f497fa17b03515c96f09f0e25d6.definition = {
    methods: ["delete"],
    url: '/sites/{project}/unlink-package/{package}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/sites/{project}/unlink-package/{package}'
*/
unlinkPackagece8c9f497fa17b03515c96f09f0e25d6.url = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            project: args[0],
            package: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
        package: args.package,
    }

    return unlinkPackagece8c9f497fa17b03515c96f09f0e25d6.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{package}', parsedArgs.package.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/sites/{project}/unlink-package/{package}'
*/
unlinkPackagece8c9f497fa17b03515c96f09f0e25d6.delete = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackagece8c9f497fa17b03515c96f09f0e25d6.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/projects/{project}/unlink-package/{package}'
*/
const unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d.url(args, options),
    method: 'delete',
})

unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d.definition = {
    methods: ["delete"],
    url: '/projects/{project}/unlink-package/{package}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/projects/{project}/unlink-package/{package}'
*/
unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d.url = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            project: args[0],
            package: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
        package: args.package,
    }

    return unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{package}', parsedArgs.package.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/projects/{project}/unlink-package/{package}'
*/
unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d.delete = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/sites/{project}/unlink-package/{package}'
*/
const unlinkPackage8f15b863bd517afceac82e52ec6686d7 = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage8f15b863bd517afceac82e52ec6686d7.url(args, options),
    method: 'delete',
})

unlinkPackage8f15b863bd517afceac82e52ec6686d7.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/sites/{project}/unlink-package/{package}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/sites/{project}/unlink-package/{package}'
*/
unlinkPackage8f15b863bd517afceac82e52ec6686d7.url = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
            package: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
        package: args.package,
    }

    return unlinkPackage8f15b863bd517afceac82e52ec6686d7.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace('{package}', parsedArgs.package.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/sites/{project}/unlink-package/{package}'
*/
unlinkPackage8f15b863bd517afceac82e52ec6686d7.delete = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage8f15b863bd517afceac82e52ec6686d7.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/projects/{project}/unlink-package/{package}'
*/
const unlinkPackagec3105fc1806ad2d6e647baa15760e353 = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackagec3105fc1806ad2d6e647baa15760e353.url(args, options),
    method: 'delete',
})

unlinkPackagec3105fc1806ad2d6e647baa15760e353.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/projects/{project}/unlink-package/{package}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/projects/{project}/unlink-package/{package}'
*/
unlinkPackagec3105fc1806ad2d6e647baa15760e353.url = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
            package: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
        package: args.package,
    }

    return unlinkPackagec3105fc1806ad2d6e647baa15760e353.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace('{package}', parsedArgs.package.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/projects/{project}/unlink-package/{package}'
*/
unlinkPackagec3105fc1806ad2d6e647baa15760e353.delete = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackagec3105fc1806ad2d6e647baa15760e353.url(args, options),
    method: 'delete',
})

export const unlinkPackage = {
    '/sites/{project}/unlink-package/{package}': unlinkPackagece8c9f497fa17b03515c96f09f0e25d6,
    '/projects/{project}/unlink-package/{package}': unlinkPackage0aeac38e5ae421fd0ee03a76d1fadb3d,
    '/environments/{environment}/sites/{project}/unlink-package/{package}': unlinkPackage8f15b863bd517afceac82e52ec6686d7,
    '/environments/{environment}/projects/{project}/unlink-package/{package}': unlinkPackagec3105fc1806ad2d6e647baa15760e353,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
export const settings = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
settings.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return settings.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
settings.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
settings.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::updateSettings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:307
* @route '/environments/{environment}/settings'
*/
export const updateSettings = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSettings.url(args, options),
    method: 'post',
})

updateSettings.definition = {
    methods: ["post"],
    url: '/environments/{environment}/settings',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::updateSettings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:307
* @route '/environments/{environment}/settings'
*/
updateSettings.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return updateSettings.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::updateSettings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:307
* @route '/environments/{environment}/settings'
*/
updateSettings.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateSettings.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
export const show = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
show.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return show.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
show.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
show.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getAllTlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
export const getAllTlds = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAllTlds.url(options),
    method: 'get',
})

getAllTlds.definition = {
    methods: ["get","head"],
    url: '/api/environments/tlds',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getAllTlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
getAllTlds.url = (options?: RouteQueryOptions) => {
    return getAllTlds.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getAllTlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
getAllTlds.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getAllTlds.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getAllTlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
getAllTlds.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getAllTlds.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::testConnection
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:206
* @route '/api/environments/{environment}/test-connection'
*/
export const testConnection = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(args, options),
    method: 'post',
})

testConnection.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/test-connection',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::testConnection
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:206
* @route '/api/environments/{environment}/test-connection'
*/
testConnection.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return testConnection.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::testConnection
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:206
* @route '/api/environments/{environment}/test-connection'
*/
testConnection.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: testConnection.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/environments/{environment}/status'
*/
const statusd8543e674baae16aa83d4ee70b868f8b = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statusd8543e674baae16aa83d4ee70b868f8b.url(args, options),
    method: 'get',
})

statusd8543e674baae16aa83d4ee70b868f8b.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/environments/{environment}/status'
*/
statusd8543e674baae16aa83d4ee70b868f8b.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return statusd8543e674baae16aa83d4ee70b868f8b.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/environments/{environment}/status'
*/
statusd8543e674baae16aa83d4ee70b868f8b.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: statusd8543e674baae16aa83d4ee70b868f8b.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/environments/{environment}/status'
*/
statusd8543e674baae16aa83d4ee70b868f8b.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: statusd8543e674baae16aa83d4ee70b868f8b.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
const status683943a154e6cf927cb8b41a9837fd47 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status683943a154e6cf927cb8b41a9837fd47.url(options),
    method: 'get',
})

status683943a154e6cf927cb8b41a9837fd47.definition = {
    methods: ["get","head"],
    url: '/api/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
status683943a154e6cf927cb8b41a9837fd47.url = (options?: RouteQueryOptions) => {
    return status683943a154e6cf927cb8b41a9837fd47.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
status683943a154e6cf927cb8b41a9837fd47.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status683943a154e6cf927cb8b41a9837fd47.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
status683943a154e6cf927cb8b41a9837fd47.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status683943a154e6cf927cb8b41a9837fd47.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/services/status'
*/
const status9f538582780b72a2105689ca4db4105c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status9f538582780b72a2105689ca4db4105c.url(options),
    method: 'get',
})

status9f538582780b72a2105689ca4db4105c.definition = {
    methods: ["get","head"],
    url: '/api/services/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/services/status'
*/
status9f538582780b72a2105689ca4db4105c.url = (options?: RouteQueryOptions) => {
    return status9f538582780b72a2105689ca4db4105c.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/services/status'
*/
status9f538582780b72a2105689ca4db4105c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status9f538582780b72a2105689ca4db4105c.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/services/status'
*/
status9f538582780b72a2105689ca4db4105c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status9f538582780b72a2105689ca4db4105c.url(options),
    method: 'head',
})

export const status = {
    '/api/environments/{environment}/status': statusd8543e674baae16aa83d4ee70b868f8b,
    '/api/status': status683943a154e6cf927cb8b41a9837fd47,
    '/api/services/status': status9f538582780b72a2105689ca4db4105c,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/environments/{environment}/sites'
*/
const sitesApid911409852a44e63edc01f3a0646c3cf = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesApid911409852a44e63edc01f3a0646c3cf.url(args, options),
    method: 'get',
})

sitesApid911409852a44e63edc01f3a0646c3cf.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/environments/{environment}/sites'
*/
sitesApid911409852a44e63edc01f3a0646c3cf.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return sitesApid911409852a44e63edc01f3a0646c3cf.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/environments/{environment}/sites'
*/
sitesApid911409852a44e63edc01f3a0646c3cf.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesApid911409852a44e63edc01f3a0646c3cf.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/environments/{environment}/sites'
*/
sitesApid911409852a44e63edc01f3a0646c3cf.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesApid911409852a44e63edc01f3a0646c3cf.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
const sitesApi693618c018aaa2aa9672591ffdda4500 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesApi693618c018aaa2aa9672591ffdda4500.url(options),
    method: 'get',
})

sitesApi693618c018aaa2aa9672591ffdda4500.definition = {
    methods: ["get","head"],
    url: '/api/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
sitesApi693618c018aaa2aa9672591ffdda4500.url = (options?: RouteQueryOptions) => {
    return sitesApi693618c018aaa2aa9672591ffdda4500.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
sitesApi693618c018aaa2aa9672591ffdda4500.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesApi693618c018aaa2aa9672591ffdda4500.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
sitesApi693618c018aaa2aa9672591ffdda4500.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesApi693618c018aaa2aa9672591ffdda4500.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
const sitesApi8b46e609ff6aa5711101f5859f1d83b4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesApi8b46e609ff6aa5711101f5859f1d83b4.url(options),
    method: 'get',
})

sitesApi8b46e609ff6aa5711101f5859f1d83b4.definition = {
    methods: ["get","head"],
    url: '/api/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
sitesApi8b46e609ff6aa5711101f5859f1d83b4.url = (options?: RouteQueryOptions) => {
    return sitesApi8b46e609ff6aa5711101f5859f1d83b4.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
sitesApi8b46e609ff6aa5711101f5859f1d83b4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sitesApi8b46e609ff6aa5711101f5859f1d83b4.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sitesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
sitesApi8b46e609ff6aa5711101f5859f1d83b4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sitesApi8b46e609ff6aa5711101f5859f1d83b4.url(options),
    method: 'head',
})

export const sitesApi = {
    '/api/environments/{environment}/sites': sitesApid911409852a44e63edc01f3a0646c3cf,
    '/api/sites': sitesApi693618c018aaa2aa9672591ffdda4500,
    '/api/projects': sitesApi8b46e609ff6aa5711101f5859f1d83b4,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/environments/{environment}/config'
*/
const getConfig42c5617d61f55d51b40423dd1c4340e0 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getConfig42c5617d61f55d51b40423dd1c4340e0.url(args, options),
    method: 'get',
})

getConfig42c5617d61f55d51b40423dd1c4340e0.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/environments/{environment}/config'
*/
getConfig42c5617d61f55d51b40423dd1c4340e0.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return getConfig42c5617d61f55d51b40423dd1c4340e0.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/environments/{environment}/config'
*/
getConfig42c5617d61f55d51b40423dd1c4340e0.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getConfig42c5617d61f55d51b40423dd1c4340e0.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/environments/{environment}/config'
*/
getConfig42c5617d61f55d51b40423dd1c4340e0.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getConfig42c5617d61f55d51b40423dd1c4340e0.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
const getConfig6aaa47bb5c9721ac27ade360b9d7c290 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getConfig6aaa47bb5c9721ac27ade360b9d7c290.url(options),
    method: 'get',
})

getConfig6aaa47bb5c9721ac27ade360b9d7c290.definition = {
    methods: ["get","head"],
    url: '/api/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
getConfig6aaa47bb5c9721ac27ade360b9d7c290.url = (options?: RouteQueryOptions) => {
    return getConfig6aaa47bb5c9721ac27ade360b9d7c290.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
getConfig6aaa47bb5c9721ac27ade360b9d7c290.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getConfig6aaa47bb5c9721ac27ade360b9d7c290.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
getConfig6aaa47bb5c9721ac27ade360b9d7c290.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getConfig6aaa47bb5c9721ac27ade360b9d7c290.url(options),
    method: 'head',
})

export const getConfig = {
    '/api/environments/{environment}/config': getConfig42c5617d61f55d51b40423dd1c4340e0,
    '/api/config': getConfig6aaa47bb5c9721ac27ade360b9d7c290,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/environments/{environment}/worktrees'
*/
const worktreesbe8898edba077d3715dcedb759859a78 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: worktreesbe8898edba077d3715dcedb759859a78.url(args, options),
    method: 'get',
})

worktreesbe8898edba077d3715dcedb759859a78.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/worktrees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/environments/{environment}/worktrees'
*/
worktreesbe8898edba077d3715dcedb759859a78.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return worktreesbe8898edba077d3715dcedb759859a78.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/environments/{environment}/worktrees'
*/
worktreesbe8898edba077d3715dcedb759859a78.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: worktreesbe8898edba077d3715dcedb759859a78.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/environments/{environment}/worktrees'
*/
worktreesbe8898edba077d3715dcedb759859a78.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: worktreesbe8898edba077d3715dcedb759859a78.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
const worktreesf3c4bdf0cccc1abd3ad832aa34ea8912 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.url(options),
    method: 'get',
})

worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.definition = {
    methods: ["get","head"],
    url: '/api/worktrees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.url = (options?: RouteQueryOptions) => {
    return worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: worktreesf3c4bdf0cccc1abd3ad832aa34ea8912.url(options),
    method: 'head',
})

export const worktrees = {
    '/api/environments/{environment}/worktrees': worktreesbe8898edba077d3715dcedb759859a78,
    '/api/worktrees': worktreesf3c4bdf0cccc1abd3ad832aa34ea8912,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/environments/{environment}/workspaces'
*/
const workspacesApi30ed4ebf0b945715ecddb0702a4d7278 = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspacesApi30ed4ebf0b945715ecddb0702a4d7278.url(args, options),
    method: 'get',
})

workspacesApi30ed4ebf0b945715ecddb0702a4d7278.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/environments/{environment}/workspaces'
*/
workspacesApi30ed4ebf0b945715ecddb0702a4d7278.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return workspacesApi30ed4ebf0b945715ecddb0702a4d7278.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/environments/{environment}/workspaces'
*/
workspacesApi30ed4ebf0b945715ecddb0702a4d7278.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspacesApi30ed4ebf0b945715ecddb0702a4d7278.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/environments/{environment}/workspaces'
*/
workspacesApi30ed4ebf0b945715ecddb0702a4d7278.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspacesApi30ed4ebf0b945715ecddb0702a4d7278.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
const workspacesApid2c908c02f95eff99f745ab67bf05ed7 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspacesApid2c908c02f95eff99f745ab67bf05ed7.url(options),
    method: 'get',
})

workspacesApid2c908c02f95eff99f745ab67bf05ed7.definition = {
    methods: ["get","head"],
    url: '/api/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
workspacesApid2c908c02f95eff99f745ab67bf05ed7.url = (options?: RouteQueryOptions) => {
    return workspacesApid2c908c02f95eff99f745ab67bf05ed7.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
workspacesApid2c908c02f95eff99f745ab67bf05ed7.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspacesApid2c908c02f95eff99f745ab67bf05ed7.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspacesApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
workspacesApid2c908c02f95eff99f745ab67bf05ed7.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspacesApid2c908c02f95eff99f745ab67bf05ed7.url(options),
    method: 'head',
})

export const workspacesApi = {
    '/api/environments/{environment}/workspaces': workspacesApi30ed4ebf0b945715ecddb0702a4d7278,
    '/api/workspaces': workspacesApid2c908c02f95eff99f745ab67bf05ed7,
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaceApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1408
* @route '/api/environments/{environment}/workspaces/{workspace}'
*/
export const workspaceApi = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaceApi.url(args, options),
    method: 'get',
})

workspaceApi.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/workspaces/{workspace}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaceApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1408
* @route '/api/environments/{environment}/workspaces/{workspace}'
*/
workspaceApi.url = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            workspace: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        workspace: args.workspace,
    }

    return workspaceApi.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{workspace}', parsedArgs.workspace.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaceApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1408
* @route '/api/environments/{environment}/workspaces/{workspace}'
*/
workspaceApi.get = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaceApi.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaceApi
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1408
* @route '/api/environments/{environment}/workspaces/{workspace}'
*/
workspaceApi.head = (args: { environment: number | { id: number }, workspace: string | number } | [environment: number | { id: number }, workspace: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspaceApi.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::hostServiceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:614
* @route '/api/environments/{environment}/host-services/{service}/logs'
*/
export const hostServiceLogs = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: hostServiceLogs.url(args, options),
    method: 'get',
})

hostServiceLogs.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/host-services/{service}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::hostServiceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:614
* @route '/api/environments/{environment}/host-services/{service}/logs'
*/
hostServiceLogs.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return hostServiceLogs.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::hostServiceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:614
* @route '/api/environments/{environment}/host-services/{service}/logs'
*/
hostServiceLogs.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: hostServiceLogs.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::hostServiceLogs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:614
* @route '/api/environments/{environment}/host-services/{service}/logs'
*/
hostServiceLogs.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: hostServiceLogs.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1589
* @route '/api/environments/{environment}/php/config/{version?}'
*/
export const getPhpConfig = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPhpConfig.url(args, options),
    method: 'get',
})

getPhpConfig.definition = {
    methods: ["get","head"],
    url: '/api/environments/{environment}/php/config/{version?}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1589
* @route '/api/environments/{environment}/php/config/{version?}'
*/
getPhpConfig.url = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            version: args[1],
        }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
        "version",
    ])

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        version: args.version,
    }

    return getPhpConfig.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{version?}', parsedArgs.version?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1589
* @route '/api/environments/{environment}/php/config/{version?}'
*/
getPhpConfig.get = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: getPhpConfig.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::getPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1589
* @route '/api/environments/{environment}/php/config/{version?}'
*/
getPhpConfig.head = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: getPhpConfig.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1602
* @route '/api/environments/{environment}/php/config/{version?}'
*/
export const setPhpConfig = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setPhpConfig.url(args, options),
    method: 'post',
})

setPhpConfig.definition = {
    methods: ["post"],
    url: '/api/environments/{environment}/php/config/{version?}',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1602
* @route '/api/environments/{environment}/php/config/{version?}'
*/
setPhpConfig.url = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            version: args[1],
        }
    }

    args = applyUrlDefaults(args)

    validateParameters(args, [
        "version",
    ])

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        version: args.version,
    }

    return setPhpConfig.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{version?}', parsedArgs.version?.toString() ?? '')
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setPhpConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1602
* @route '/api/environments/{environment}/php/config/{version?}'
*/
setPhpConfig.post = (args: { environment: number | { id: number }, version?: string | number } | [environment: number | { id: number }, version: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setPhpConfig.url(args, options),
    method: 'post',
})

const EnvironmentController = { setDefault, runDoctor, quickCheck, fixDoctorIssue, sitesPage, servicesPage, orchestrator, enableOrchestrator, disableOrchestrator, installOrchestrator, detectOrchestrator, reconcileOrchestrator, orchestratorServices, orchestratorSites, start, stop, restart, changePhp, resetPhp, availableServices, startService, stopService, restartService, startHostService, stopHostService, restartHostService, serviceLogs, enableService, disableService, configureService, serviceInfo, saveConfig, getReverbConfig, unlinkWorktree, refreshWorktrees, createSite, storeSite, destroySite, rebuildSite, provisionStatus, templateDefaults, githubUser, githubOrgs, githubRepoExists, linearTeams, workspaces, createWorkspace, storeWorkspace, showWorkspace, destroyWorkspace, addWorkspaceProject, removeWorkspaceProject, linkedPackages, linkPackage, unlinkPackage, settings, updateSettings, show, getAllTlds, testConnection, status, sitesApi, getConfig, worktrees, workspacesApi, workspaceApi, hostServiceLogs, getPhpConfig, setPhpConfig }

export default EnvironmentController