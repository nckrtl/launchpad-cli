import Http from './Http'

const Orbit = {
    Http: Object.assign(Http, Http),
}

export default Orbit