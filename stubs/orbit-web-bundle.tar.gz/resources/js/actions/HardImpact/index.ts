import Orbit from './Orbit'

const HardImpact = {
    Orbit: Object.assign(Orbit, Orbit),
}

export default HardImpact