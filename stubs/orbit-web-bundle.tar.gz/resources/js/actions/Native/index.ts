import Laravel from './Laravel'

const Native = {
    Laravel: Object.assign(Laravel, Laravel),
}

export default Native