import Http from './Http'

const Laravel = {
    Http: Object.assign(Http, Http),
}

export default Laravel