// Auto-generated file – do not edit manually

export { default as HomeController } from '@/actions/App/Http/Controllers/HomeController.ts';
