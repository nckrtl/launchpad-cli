import '../css/app.css';

import { initializeCraft } from 'virtual:craft';

initializeCraft();
