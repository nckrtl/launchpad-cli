import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/sites/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/sites/create'
*/
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
export const create = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
create.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return create.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
create.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::create
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:864
* @route '/environments/{environment}/sites/create'
*/
create.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/sites'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/sites'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/sites'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/sites'
*/
export const store = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/environments/{environment}/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/sites'
*/
store.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return store.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/environments/{environment}/sites'
*/
store.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/sites/{projectName}'
*/
export const destroy = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/sites/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/sites/{projectName}'
*/
destroy.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return destroy.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/sites/{projectName}'
*/
destroy.delete = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/sites/{projectName}'
*/
export const destroy = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/sites/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/sites/{projectName}'
*/
destroy.url = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectName: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectName: args.projectName,
    }

    return destroy.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/environments/{environment}/sites/{projectName}'
*/
destroy.delete = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/sites/{projectName}/rebuild'
*/
export const rebuild = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuild.url(args, options),
    method: 'post',
})

rebuild.definition = {
    methods: ["post"],
    url: '/sites/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/sites/{projectName}/rebuild'
*/
rebuild.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return rebuild.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/sites/{projectName}/rebuild'
*/
rebuild.post = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuild.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/sites/{projectName}/rebuild'
*/
export const rebuild = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuild.url(args, options),
    method: 'post',
})

rebuild.definition = {
    methods: ["post"],
    url: '/environments/{environment}/sites/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/sites/{projectName}/rebuild'
*/
rebuild.url = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectName: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectName: args.projectName,
    }

    return rebuild.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/environments/{environment}/sites/{projectName}/rebuild'
*/
rebuild.post = (args: { environment: number | { id: number }, projectName: string | number } | [environment: number | { id: number }, projectName: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuild.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
export const provisionStatus = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus.url(args, options),
    method: 'get',
})

provisionStatus.definition = {
    methods: ["get","head"],
    url: '/sites/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
provisionStatus.url = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectSlug: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectSlug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectSlug: args.projectSlug,
    }

    return provisionStatus.definition.url
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
provisionStatus.get = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/sites/{projectSlug}/provision-status'
*/
provisionStatus.head = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatus.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
export const provisionStatus = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus.url(args, options),
    method: 'get',
})

provisionStatus.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
provisionStatus.url = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            projectSlug: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        projectSlug: args.projectSlug,
    }

    return provisionStatus.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
provisionStatus.get = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/environments/{environment}/sites/{projectSlug}/provision-status'
*/
provisionStatus.head = (args: { environment: number | { id: number }, projectSlug: string | number } | [environment: number | { id: number }, projectSlug: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatus.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
export const linkedPackages = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages.url(args, options),
    method: 'get',
})

linkedPackages.definition = {
    methods: ["get","head"],
    url: '/sites/{project}/linked-packages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
linkedPackages.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
    }

    return linkedPackages.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
linkedPackages.get = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/sites/{project}/linked-packages'
*/
linkedPackages.head = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linkedPackages.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
export const linkedPackages = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages.url(args, options),
    method: 'get',
})

linkedPackages.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites/{project}/linked-packages',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
linkedPackages.url = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
    }

    return linkedPackages.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
linkedPackages.get = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linkedPackages.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkedPackages
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1490
* @route '/environments/{environment}/sites/{project}/linked-packages'
*/
linkedPackages.head = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linkedPackages.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/sites/{project}/link-package'
*/
export const linkPackage = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage.url(args, options),
    method: 'post',
})

linkPackage.definition = {
    methods: ["post"],
    url: '/sites/{project}/link-package',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/sites/{project}/link-package'
*/
linkPackage.url = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { project: args }
    }

    if (Array.isArray(args)) {
        args = {
            project: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
    }

    return linkPackage.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/sites/{project}/link-package'
*/
linkPackage.post = (args: { project: string | number } | [project: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/sites/{project}/link-package'
*/
export const linkPackage = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage.url(args, options),
    method: 'post',
})

linkPackage.definition = {
    methods: ["post"],
    url: '/environments/{environment}/sites/{project}/link-package',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/sites/{project}/link-package'
*/
linkPackage.url = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
    }

    return linkPackage.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1510
* @route '/environments/{environment}/sites/{project}/link-package'
*/
linkPackage.post = (args: { environment: number | { id: number }, project: string | number } | [environment: number | { id: number }, project: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: linkPackage.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/sites/{project}/unlink-package/{package}'
*/
export const unlinkPackage = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage.url(args, options),
    method: 'delete',
})

unlinkPackage.definition = {
    methods: ["delete"],
    url: '/sites/{project}/unlink-package/{package}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/sites/{project}/unlink-package/{package}'
*/
unlinkPackage.url = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            project: args[0],
            package: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        project: args.project,
        package: args.package,
    }

    return unlinkPackage.definition.url
            .replace('{project}', parsedArgs.project.toString())
            .replace('{package}', parsedArgs.package.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/sites/{project}/unlink-package/{package}'
*/
unlinkPackage.delete = (args: { project: string | number, package: string | number } | [project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/sites/{project}/unlink-package/{package}'
*/
export const unlinkPackage = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage.url(args, options),
    method: 'delete',
})

unlinkPackage.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/sites/{project}/unlink-package/{package}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/sites/{project}/unlink-package/{package}'
*/
unlinkPackage.url = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            project: args[1],
            package: args[2],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        project: args.project,
        package: args.package,
    }

    return unlinkPackage.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{project}', parsedArgs.project.toString())
            .replace('{package}', parsedArgs.package.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::unlinkPackage
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1539
* @route '/environments/{environment}/sites/{project}/unlink-package/{package}'
*/
unlinkPackage.delete = (args: { environment: number | { id: number }, project: string | number, package: string | number } | [environment: number | { id: number }, project: string | number, packageParam: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: unlinkPackage.url(args, options),
    method: 'delete',
})

const sites = {
    create: Object.assign(create, create),
    store: Object.assign(store, store),
    destroy: Object.assign(destroy, destroy),
    rebuild: Object.assign(rebuild, rebuild),
    provisionStatus: Object.assign(provisionStatus, provisionStatus),
    linkedPackages: Object.assign(linkedPackages, linkedPackages),
    linkPackage: Object.assign(linkPackage, linkPackage),
    unlinkPackage: Object.assign(unlinkPackage, unlinkPackage),
}

export default sites