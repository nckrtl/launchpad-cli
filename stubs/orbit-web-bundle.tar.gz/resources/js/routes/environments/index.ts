import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../wayfinder'
import doctorB93ea904d2d0 from './doctor'
import sitesE38ead27705d from './sites'
import projects46b84a6f58dc from './projects'
import services11ad26902f30 from './services'
import orchestrator73e4f1C89f72 from './orchestrator'
import php55d7dfA5993c from './php'
import hostServices from './host-services'
import config from './config'
import worktrees from './worktrees'
import dns from './dns'
import workspaces8282b937d977 from './workspaces'
import settings69f00b from './settings'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/set-default'
*/
export const setDefault = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefault.url(options),
    method: 'post',
})

setDefault.definition = {
    methods: ["post"],
    url: '/set-default',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/set-default'
*/
setDefault.url = (options?: RouteQueryOptions) => {
    return setDefault.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/set-default'
*/
setDefault.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefault.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/environments/{environment}/set-default'
*/
export const setDefault = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefault.url(args, options),
    method: 'post',
})

setDefault.definition = {
    methods: ["post"],
    url: '/environments/{environment}/set-default',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/environments/{environment}/set-default'
*/
setDefault.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return setDefault.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::setDefault
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:195
* @route '/environments/{environment}/set-default'
*/
setDefault.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: setDefault.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
export const doctor = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: doctor.url(options),
    method: 'get',
})

doctor.definition = {
    methods: ["get","head"],
    url: '/doctor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
doctor.url = (options?: RouteQueryOptions) => {
    return doctor.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
doctor.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: doctor.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/doctor'
*/
doctor.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: doctor.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
export const doctor = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: doctor.url(args, options),
    method: 'get',
})

doctor.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/doctor',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
doctor.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return doctor.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
doctor.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: doctor.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::doctor
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1559
* @route '/environments/{environment}/doctor'
*/
doctor.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: doctor.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
export const sites = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
sites.url = (options?: RouteQueryOptions) => {
    return sites.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
sites.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/sites'
*/
sites.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
export const sites = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(args, options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
sites.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return sites.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
sites.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/sites'
*/
sites.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
export const projects = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(options),
    method: 'get',
})

projects.definition = {
    methods: ["get","head"],
    url: '/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
projects.url = (options?: RouteQueryOptions) => {
    return projects.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
projects.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/projects'
*/
projects.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: projects.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
export const projects = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(args, options),
    method: 'get',
})

projects.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
projects.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return projects.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
projects.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:257
* @route '/environments/{environment}/projects'
*/
projects.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: projects.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
export const services = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(options),
    method: 'get',
})

services.definition = {
    methods: ["get","head"],
    url: '/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
services.url = (options?: RouteQueryOptions) => {
    return services.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
services.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/services'
*/
services.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: services.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
export const services = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(args, options),
    method: 'get',
})

services.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
services.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return services.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
services.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:272
* @route '/environments/{environment}/services'
*/
services.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: services.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
export const orchestrator = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestrator.url(options),
    method: 'get',
})

orchestrator.definition = {
    methods: ["get","head"],
    url: '/orchestrator',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
orchestrator.url = (options?: RouteQueryOptions) => {
    return orchestrator.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
orchestrator.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestrator.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/orchestrator'
*/
orchestrator.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestrator.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
export const orchestrator = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestrator.url(args, options),
    method: 'get',
})

orchestrator.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
orchestrator.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return orchestrator.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
orchestrator.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: orchestrator.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::orchestrator
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:324
* @route '/environments/{environment}/orchestrator'
*/
orchestrator.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: orchestrator.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/start'
*/
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/start'
*/
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/start'
*/
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/environments/{environment}/start'
*/
export const start = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/environments/{environment}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/environments/{environment}/start'
*/
start.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return start.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/environments/{environment}/start'
*/
start.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/stop'
*/
export const stop = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/stop'
*/
stop.url = (options?: RouteQueryOptions) => {
    return stop.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/stop'
*/
stop.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/environments/{environment}/stop'
*/
export const stop = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/environments/{environment}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/environments/{environment}/stop'
*/
stop.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return stop.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/environments/{environment}/stop'
*/
stop.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/restart'
*/
export const restart = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/restart'
*/
restart.url = (options?: RouteQueryOptions) => {
    return restart.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/restart'
*/
restart.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/environments/{environment}/restart'
*/
export const restart = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/environments/{environment}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/environments/{environment}/restart'
*/
restart.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return restart.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/environments/{environment}/restart'
*/
restart.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::php
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/php'
*/
export const php = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: php.url(options),
    method: 'post',
})

php.definition = {
    methods: ["post"],
    url: '/php',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::php
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/php'
*/
php.url = (options?: RouteQueryOptions) => {
    return php.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::php
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/php'
*/
php.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: php.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::php
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/environments/{environment}/php'
*/
export const php = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: php.url(args, options),
    method: 'post',
})

php.definition = {
    methods: ["post"],
    url: '/environments/{environment}/php',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::php
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/environments/{environment}/php'
*/
php.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return php.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::php
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:673
* @route '/environments/{environment}/php'
*/
php.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: php.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
export const reverbConfig = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reverbConfig.url(options),
    method: 'get',
})

reverbConfig.definition = {
    methods: ["get","head"],
    url: '/reverb-config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
reverbConfig.url = (options?: RouteQueryOptions) => {
    return reverbConfig.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
reverbConfig.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reverbConfig.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/reverb-config'
*/
reverbConfig.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reverbConfig.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
export const reverbConfig = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reverbConfig.url(args, options),
    method: 'get',
})

reverbConfig.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/reverb-config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
reverbConfig.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return reverbConfig.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
reverbConfig.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reverbConfig.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reverbConfig
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:706
* @route '/environments/{environment}/reverb-config'
*/
reverbConfig.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reverbConfig.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/template-defaults'
*/
export const templateDefaults = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults.url(options),
    method: 'post',
})

templateDefaults.definition = {
    methods: ["post"],
    url: '/template-defaults',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/template-defaults'
*/
templateDefaults.url = (options?: RouteQueryOptions) => {
    return templateDefaults.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/template-defaults'
*/
templateDefaults.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/environments/{environment}/template-defaults'
*/
export const templateDefaults = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults.url(args, options),
    method: 'post',
})

templateDefaults.definition = {
    methods: ["post"],
    url: '/environments/{environment}/template-defaults',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/environments/{environment}/template-defaults'
*/
templateDefaults.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return templateDefaults.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::templateDefaults
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1112
* @route '/environments/{environment}/template-defaults'
*/
templateDefaults.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: templateDefaults.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
export const githubUser = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser.url(options),
    method: 'get',
})

githubUser.definition = {
    methods: ["get","head"],
    url: '/github-user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
githubUser.url = (options?: RouteQueryOptions) => {
    return githubUser.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
githubUser.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/github-user'
*/
githubUser.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubUser.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
export const githubUser = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser.url(args, options),
    method: 'get',
})

githubUser.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/github-user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
githubUser.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return githubUser.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
githubUser.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubUser.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubUser
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1034
* @route '/environments/{environment}/github-user'
*/
githubUser.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubUser.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
export const githubOrgs = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgs.url(options),
    method: 'get',
})

githubOrgs.definition = {
    methods: ["get","head"],
    url: '/github-orgs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
githubOrgs.url = (options?: RouteQueryOptions) => {
    return githubOrgs.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
githubOrgs.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgs.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/github-orgs'
*/
githubOrgs.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubOrgs.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
export const githubOrgs = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgs.url(args, options),
    method: 'get',
})

githubOrgs.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/github-orgs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
githubOrgs.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return githubOrgs.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
githubOrgs.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: githubOrgs.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubOrgs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1047
* @route '/environments/{environment}/github-orgs'
*/
githubOrgs.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: githubOrgs.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/github-repo-exists'
*/
export const githubRepoExists = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExists.url(options),
    method: 'post',
})

githubRepoExists.definition = {
    methods: ["post"],
    url: '/github-repo-exists',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/github-repo-exists'
*/
githubRepoExists.url = (options?: RouteQueryOptions) => {
    return githubRepoExists.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/github-repo-exists'
*/
githubRepoExists.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExists.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/environments/{environment}/github-repo-exists'
*/
export const githubRepoExists = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExists.url(args, options),
    method: 'post',
})

githubRepoExists.definition = {
    methods: ["post"],
    url: '/environments/{environment}/github-repo-exists',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/environments/{environment}/github-repo-exists'
*/
githubRepoExists.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return githubRepoExists.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::githubRepoExists
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1058
* @route '/environments/{environment}/github-repo-exists'
*/
githubRepoExists.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: githubRepoExists.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
export const linearTeams = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams.url(options),
    method: 'get',
})

linearTeams.definition = {
    methods: ["get","head"],
    url: '/linear-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
linearTeams.url = (options?: RouteQueryOptions) => {
    return linearTeams.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
linearTeams.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/linear-teams'
*/
linearTeams.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linearTeams.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
export const linearTeams = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams.url(args, options),
    method: 'get',
})

linearTeams.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/linear-teams',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
linearTeams.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return linearTeams.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
linearTeams.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: linearTeams.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::linearTeams
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1077
* @route '/environments/{environment}/linear-teams'
*/
linearTeams.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: linearTeams.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
export const workspaces = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces.url(options),
    method: 'get',
})

workspaces.definition = {
    methods: ["get","head"],
    url: '/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
workspaces.url = (options?: RouteQueryOptions) => {
    return workspaces.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
workspaces.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/workspaces'
*/
workspaces.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspaces.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
export const workspaces = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces.url(args, options),
    method: 'get',
})

workspaces.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
workspaces.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return workspaces.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
workspaces.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1338
* @route '/environments/{environment}/workspaces'
*/
workspaces.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspaces.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
export const settings = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
settings.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return settings.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
settings.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::settings
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:297
* @route '/environments/{environment}/settings'
*/
settings.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
export const show = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
show.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return show.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
show.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::show
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:106
* @route '/environments/{environment}'
*/
show.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

const environments = {
    setDefault: Object.assign(setDefault, setDefault),
    doctor: Object.assign(doctor, doctorB93ea904d2d0),
    sites: Object.assign(sites, sitesE38ead27705d),
    projects: Object.assign(projects, projects46b84a6f58dc),
    services: Object.assign(services, services11ad26902f30),
    orchestrator: Object.assign(orchestrator, orchestrator73e4f1C89f72),
    start: Object.assign(start, start),
    stop: Object.assign(stop, stop),
    restart: Object.assign(restart, restart),
    php: Object.assign(php, php55d7dfA5993c),
    hostServices: Object.assign(hostServices, hostServices),
    config: Object.assign(config, config),
    reverbConfig: Object.assign(reverbConfig, reverbConfig),
    worktrees: Object.assign(worktrees, worktrees),
    templateDefaults: Object.assign(templateDefaults, templateDefaults),
    githubUser: Object.assign(githubUser, githubUser),
    githubOrgs: Object.assign(githubOrgs, githubOrgs),
    githubRepoExists: Object.assign(githubRepoExists, githubRepoExists),
    linearTeams: Object.assign(linearTeams, linearTeams),
    dns: Object.assign(dns, dns),
    workspaces: Object.assign(workspaces, workspaces8282b937d977),
    settings: Object.assign(settings, settings69f00b),
    show: Object.assign(show, show),
}

export default environments