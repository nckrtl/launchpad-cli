import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/host-services/{service}/start'
*/
export const start = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/host-services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/host-services/{service}/start'
*/
start.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return start.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/host-services/{service}/start'
*/
start.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/environments/{environment}/host-services/{service}/start'
*/
export const start = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/environments/{environment}/host-services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/environments/{environment}/host-services/{service}/start'
*/
start.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return start.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:554
* @route '/environments/{environment}/host-services/{service}/start'
*/
start.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/host-services/{service}/stop'
*/
export const stop = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/host-services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/host-services/{service}/stop'
*/
stop.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return stop.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/host-services/{service}/stop'
*/
stop.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/environments/{environment}/host-services/{service}/stop'
*/
export const stop = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/environments/{environment}/host-services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/environments/{environment}/host-services/{service}/stop'
*/
stop.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return stop.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:574
* @route '/environments/{environment}/host-services/{service}/stop'
*/
stop.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/host-services/{service}/restart'
*/
export const restart = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/host-services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/host-services/{service}/restart'
*/
restart.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return restart.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/host-services/{service}/restart'
*/
restart.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/environments/{environment}/host-services/{service}/restart'
*/
export const restart = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/environments/{environment}/host-services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/environments/{environment}/host-services/{service}/restart'
*/
restart.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return restart.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:594
* @route '/environments/{environment}/host-services/{service}/restart'
*/
restart.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

const hostServices = {
    start: Object.assign(start, start),
    stop: Object.assign(stop, stop),
    restart: Object.assign(restart, restart),
}

export default hostServices