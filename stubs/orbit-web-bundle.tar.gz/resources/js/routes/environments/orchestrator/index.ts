import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/orchestrator/enable'
*/
export const enable = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(options),
    method: 'post',
})

enable.definition = {
    methods: ["post"],
    url: '/orchestrator/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/orchestrator/enable'
*/
enable.url = (options?: RouteQueryOptions) => {
    return enable.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/orchestrator/enable'
*/
enable.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/environments/{environment}/orchestrator/enable'
*/
export const enable = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(args, options),
    method: 'post',
})

enable.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/environments/{environment}/orchestrator/enable'
*/
enable.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return enable.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:334
* @route '/environments/{environment}/orchestrator/enable'
*/
enable.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/orchestrator/disable'
*/
export const disable = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disable.url(options),
    method: 'post',
})

disable.definition = {
    methods: ["post"],
    url: '/orchestrator/disable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/orchestrator/disable'
*/
disable.url = (options?: RouteQueryOptions) => {
    return disable.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/orchestrator/disable'
*/
disable.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disable.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/environments/{environment}/orchestrator/disable'
*/
export const disable = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disable.url(args, options),
    method: 'post',
})

disable.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/disable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/environments/{environment}/orchestrator/disable'
*/
disable.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return disable.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:354
* @route '/environments/{environment}/orchestrator/disable'
*/
disable.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: disable.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::install
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/orchestrator/install'
*/
export const install = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: install.url(options),
    method: 'post',
})

install.definition = {
    methods: ["post"],
    url: '/orchestrator/install',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::install
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/orchestrator/install'
*/
install.url = (options?: RouteQueryOptions) => {
    return install.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::install
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/orchestrator/install'
*/
install.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: install.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::install
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/environments/{environment}/orchestrator/install'
*/
export const install = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: install.url(args, options),
    method: 'post',
})

install.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/install',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::install
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/environments/{environment}/orchestrator/install'
*/
install.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return install.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::install
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:370
* @route '/environments/{environment}/orchestrator/install'
*/
install.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: install.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
export const detect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detect.url(options),
    method: 'get',
})

detect.definition = {
    methods: ["get","head"],
    url: '/orchestrator/detect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
detect.url = (options?: RouteQueryOptions) => {
    return detect.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
detect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detect.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/orchestrator/detect'
*/
detect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detect.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
export const detect = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detect.url(args, options),
    method: 'get',
})

detect.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/detect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
detect.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return detect.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
detect.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detect.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::detect
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:380
* @route '/environments/{environment}/orchestrator/detect'
*/
detect.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detect.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcile
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/orchestrator/reconcile'
*/
export const reconcile = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcile.url(options),
    method: 'post',
})

reconcile.definition = {
    methods: ["post"],
    url: '/orchestrator/reconcile',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcile
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/orchestrator/reconcile'
*/
reconcile.url = (options?: RouteQueryOptions) => {
    return reconcile.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcile
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/orchestrator/reconcile'
*/
reconcile.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcile.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcile
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/environments/{environment}/orchestrator/reconcile'
*/
export const reconcile = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcile.url(args, options),
    method: 'post',
})

reconcile.definition = {
    methods: ["post"],
    url: '/environments/{environment}/orchestrator/reconcile',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcile
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/environments/{environment}/orchestrator/reconcile'
*/
reconcile.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return reconcile.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::reconcile
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:390
* @route '/environments/{environment}/orchestrator/reconcile'
*/
reconcile.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reconcile.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
export const services = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(options),
    method: 'get',
})

services.definition = {
    methods: ["get","head"],
    url: '/orchestrator/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
services.url = (options?: RouteQueryOptions) => {
    return services.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
services.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/orchestrator/services'
*/
services.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: services.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
export const services = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(args, options),
    method: 'get',
})

services.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/services',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
services.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return services.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
services.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: services.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::services
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:408
* @route '/environments/{environment}/orchestrator/services'
*/
services.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: services.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
export const sites = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/orchestrator/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
sites.url = (options?: RouteQueryOptions) => {
    return sites.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
sites.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/sites'
*/
sites.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
export const sites = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(args, options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
sites.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return sites.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
sites.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/sites'
*/
sites.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
export const projects = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(options),
    method: 'get',
})

projects.definition = {
    methods: ["get","head"],
    url: '/orchestrator/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
projects.url = (options?: RouteQueryOptions) => {
    return projects.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
projects.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/orchestrator/projects'
*/
projects.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: projects.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
export const projects = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(args, options),
    method: 'get',
})

projects.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/orchestrator/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
projects.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return projects.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
projects.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:473
* @route '/environments/{environment}/orchestrator/projects'
*/
projects.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: projects.url(args, options),
    method: 'head',
})

const orchestrator = {
    enable: Object.assign(enable, enable),
    disable: Object.assign(disable, disable),
    install: Object.assign(install, install),
    detect: Object.assign(detect, detect),
    reconcile: Object.assign(reconcile, reconcile),
    services: Object.assign(services, services),
    sites: Object.assign(sites, sites),
    projects: Object.assign(projects, projects),
}

export default orchestrator