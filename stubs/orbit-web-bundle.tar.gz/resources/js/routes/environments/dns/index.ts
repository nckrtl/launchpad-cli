import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/dns'
*/
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
export const index = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/dns',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
index.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return index.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
index.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::index
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:23
* @route '/environments/{environment}/dns'
*/
index.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/dns'
*/
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/dns',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/dns'
*/
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/dns'
*/
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/environments/{environment}/dns'
*/
export const update = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/environments/{environment}/dns',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/environments/{environment}/dns'
*/
update.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return update.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\DnsController::update
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/DnsController.php:43
* @route '/environments/{environment}/dns'
*/
update.post = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

const dns = {
    index: Object.assign(index, index),
    update: Object.assign(update, update),
}

export default dns