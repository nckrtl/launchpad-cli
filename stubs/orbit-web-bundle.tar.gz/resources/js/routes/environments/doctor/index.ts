import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
export const quick = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quick.url(options),
    method: 'get',
})

quick.definition = {
    methods: ["get","head"],
    url: '/doctor/quick',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
quick.url = (options?: RouteQueryOptions) => {
    return quick.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
quick.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quick.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/doctor/quick'
*/
quick.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quick.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
export const quick = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quick.url(args, options),
    method: 'get',
})

quick.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/doctor/quick',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
quick.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return quick.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
quick.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quick.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::quick
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1569
* @route '/environments/{environment}/doctor/quick'
*/
quick.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quick.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fix
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/doctor/fix/{check}'
*/
export const fix = (args: { check: string | number } | [check: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fix.url(args, options),
    method: 'post',
})

fix.definition = {
    methods: ["post"],
    url: '/doctor/fix/{check}',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fix
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/doctor/fix/{check}'
*/
fix.url = (args: { check: string | number } | [check: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { check: args }
    }

    if (Array.isArray(args)) {
        args = {
            check: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        check: args.check,
    }

    return fix.definition.url
            .replace('{check}', parsedArgs.check.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fix
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/doctor/fix/{check}'
*/
fix.post = (args: { check: string | number } | [check: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fix.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fix
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/environments/{environment}/doctor/fix/{check}'
*/
export const fix = (args: { environment: number | { id: number }, check: string | number } | [environment: number | { id: number }, check: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fix.url(args, options),
    method: 'post',
})

fix.definition = {
    methods: ["post"],
    url: '/environments/{environment}/doctor/fix/{check}',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fix
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/environments/{environment}/doctor/fix/{check}'
*/
fix.url = (args: { environment: number | { id: number }, check: string | number } | [environment: number | { id: number }, check: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            check: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        check: args.check,
    }

    return fix.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{check}', parsedArgs.check.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::fix
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1579
* @route '/environments/{environment}/doctor/fix/{check}'
*/
fix.post = (args: { environment: number | { id: number }, check: string | number } | [environment: number | { id: number }, check: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: fix.url(args, options),
    method: 'post',
})

const doctor = {
    quick: Object.assign(quick, quick),
    fix: Object.assign(fix, fix),
}

export default doctor