import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
export const available = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: available.url(options),
    method: 'get',
})

available.definition = {
    methods: ["get","head"],
    url: '/services/available',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
available.url = (options?: RouteQueryOptions) => {
    return available.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
available.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: available.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/services/available'
*/
available.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: available.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
export const available = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: available.url(args, options),
    method: 'get',
})

available.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services/available',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
available.url = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { environment: args }
    }

    if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
        args = { environment: args.id }
    }

    if (Array.isArray(args)) {
        args = {
            environment: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
    }

    return available.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
available.get = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: available.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::available
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:624
* @route '/environments/{environment}/services/available'
*/
available.head = (args: { environment: number | { id: number } } | [environment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: available.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/services/{service}/start'
*/
export const start = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/services/{service}/start'
*/
start.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return start.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/services/{service}/start'
*/
start.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/environments/{environment}/services/{service}/start'
*/
export const start = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/environments/{environment}/services/{service}/start'
*/
start.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return start.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:544
* @route '/environments/{environment}/services/{service}/start'
*/
start.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/services/{service}/stop'
*/
export const stop = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/services/{service}/stop'
*/
stop.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return stop.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/services/{service}/stop'
*/
stop.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/environments/{environment}/services/{service}/stop'
*/
export const stop = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/environments/{environment}/services/{service}/stop'
*/
stop.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return stop.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:564
* @route '/environments/{environment}/services/{service}/stop'
*/
stop.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/services/{service}/restart'
*/
export const restart = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/services/{service}/restart'
*/
restart.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return restart.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/services/{service}/restart'
*/
restart.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/environments/{environment}/services/{service}/restart'
*/
export const restart = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/environments/{environment}/services/{service}/restart'
*/
restart.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return restart.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:584
* @route '/environments/{environment}/services/{service}/restart'
*/
restart.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
export const logs = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/services/{service}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
logs.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return logs.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
logs.get = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/services/{service}/logs'
*/
logs.head = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
export const logs = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

logs.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services/{service}/logs',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
logs.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return logs.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
logs.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: logs.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::logs
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:604
* @route '/environments/{environment}/services/{service}/logs'
*/
logs.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: logs.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/services/{service}/enable'
*/
export const enable = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(args, options),
    method: 'post',
})

enable.definition = {
    methods: ["post"],
    url: '/services/{service}/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/services/{service}/enable'
*/
enable.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return enable.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/services/{service}/enable'
*/
enable.post = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/environments/{environment}/services/{service}/enable'
*/
export const enable = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(args, options),
    method: 'post',
})

enable.definition = {
    methods: ["post"],
    url: '/environments/{environment}/services/{service}/enable',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/environments/{environment}/services/{service}/enable'
*/
enable.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return enable.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::enable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:634
* @route '/environments/{environment}/services/{service}/enable'
*/
enable.post = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: enable.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/services/{service}'
*/
export const disable = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disable.url(args, options),
    method: 'delete',
})

disable.definition = {
    methods: ["delete"],
    url: '/services/{service}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/services/{service}'
*/
disable.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return disable.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/services/{service}'
*/
disable.delete = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disable.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/environments/{environment}/services/{service}'
*/
export const disable = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disable.url(args, options),
    method: 'delete',
})

disable.definition = {
    methods: ["delete"],
    url: '/environments/{environment}/services/{service}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/environments/{environment}/services/{service}'
*/
disable.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return disable.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::disable
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:645
* @route '/environments/{environment}/services/{service}'
*/
disable.delete = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: disable.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/services/{service}/config'
*/
export const config = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: config.url(args, options),
    method: 'put',
})

config.definition = {
    methods: ["put"],
    url: '/services/{service}/config',
} satisfies RouteDefinition<["put"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/services/{service}/config'
*/
config.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return config.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/services/{service}/config'
*/
config.put = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: config.url(args, options),
    method: 'put',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/environments/{environment}/services/{service}/config'
*/
export const config = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: config.url(args, options),
    method: 'put',
})

config.definition = {
    methods: ["put"],
    url: '/environments/{environment}/services/{service}/config',
} satisfies RouteDefinition<["put"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/environments/{environment}/services/{service}/config'
*/
config.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return config.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:655
* @route '/environments/{environment}/services/{service}/config'
*/
config.put = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: config.url(args, options),
    method: 'put',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
export const info = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: info.url(args, options),
    method: 'get',
})

info.definition = {
    methods: ["get","head"],
    url: '/services/{service}/info',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
info.url = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { service: args }
    }

    if (Array.isArray(args)) {
        args = {
            service: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        service: args.service,
    }

    return info.definition.url
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
info.get = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: info.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/services/{service}/info'
*/
info.head = (args: { service: string | number } | [service: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: info.url(args, options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
export const info = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: info.url(args, options),
    method: 'get',
})

info.definition = {
    methods: ["get","head"],
    url: '/environments/{environment}/services/{service}/info',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
info.url = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
            environment: args[0],
            service: args[1],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        environment: typeof args.environment === 'object'
        ? args.environment.id
        : args.environment,
        service: args.service,
    }

    return info.definition.url
            .replace('{environment}', parsedArgs.environment.toString())
            .replace('{service}', parsedArgs.service.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
info.get = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: info.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::info
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:666
* @route '/environments/{environment}/services/{service}/info'
*/
info.head = (args: { environment: number | { id: number }, service: string | number } | [environment: number | { id: number }, service: string | number ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: info.url(args, options),
    method: 'head',
})

const services = {
    available: Object.assign(available, available),
    start: Object.assign(start, start),
    stop: Object.assign(stop, stop),
    restart: Object.assign(restart, restart),
    logs: Object.assign(logs, logs),
    enable: Object.assign(enable, enable),
    disable: Object.assign(disable, disable),
    config: Object.assign(config, config),
    info: Object.assign(info, info),
}

export default services