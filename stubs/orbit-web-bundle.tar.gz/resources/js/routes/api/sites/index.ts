import { queryParams, type RouteQueryOptions, type RouteDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/sites'
*/
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/sites',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/sites'
*/
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::store
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:879
* @route '/api/sites'
*/
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/sites/{projectName}'
*/
export const destroy = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/sites/{projectName}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/sites/{projectName}'
*/
destroy.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return destroy.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::destroy
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:965
* @route '/api/sites/{projectName}'
*/
destroy.delete = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/sites/{projectName}/rebuild'
*/
export const rebuild = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuild.url(args, options),
    method: 'post',
})

rebuild.definition = {
    methods: ["post"],
    url: '/api/sites/{projectName}/rebuild',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/sites/{projectName}/rebuild'
*/
rebuild.url = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectName: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectName: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectName: args.projectName,
    }

    return rebuild.definition.url
            .replace('{projectName}', parsedArgs.projectName.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::rebuild
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1014
* @route '/api/sites/{projectName}/rebuild'
*/
rebuild.post = (args: { projectName: string | number } | [projectName: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rebuild.url(args, options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
export const provisionStatus = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus.url(args, options),
    method: 'get',
})

provisionStatus.definition = {
    methods: ["get","head"],
    url: '/api/sites/{projectSlug}/provision-status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
provisionStatus.url = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { projectSlug: args }
    }

    if (Array.isArray(args)) {
        args = {
            projectSlug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        projectSlug: args.projectSlug,
    }

    return provisionStatus.definition.url
            .replace('{projectSlug}', parsedArgs.projectSlug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
provisionStatus.get = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: provisionStatus.url(args, options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::provisionStatus
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1024
* @route '/api/sites/{projectSlug}/provision-status'
*/
provisionStatus.head = (args: { projectSlug: string | number } | [projectSlug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: provisionStatus.url(args, options),
    method: 'head',
})

const sites = {
    store: Object.assign(store, store),
    destroy: Object.assign(destroy, destroy),
    rebuild: Object.assign(rebuild, rebuild),
    provisionStatus: Object.assign(provisionStatus, provisionStatus),
}

export default sites