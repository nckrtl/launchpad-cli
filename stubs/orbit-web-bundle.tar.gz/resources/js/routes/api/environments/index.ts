import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../../wayfinder'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::tlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
export const tlds = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tlds.url(options),
    method: 'get',
})

tlds.definition = {
    methods: ["get","head"],
    url: '/api/environments/tlds',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::tlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
tlds.url = (options?: RouteQueryOptions) => {
    return tlds.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::tlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
tlds.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tlds.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::tlds
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:799
* @route '/api/environments/tlds'
*/
tlds.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tlds.url(options),
    method: 'head',
})

const environments = {
    tlds: Object.assign(tlds, tlds),
}

export default environments