import { queryParams, type RouteQueryOptions, type RouteDefinition } from './../../wayfinder'
import environments from './environments'
import sitesE38ead from './sites'
import projects46b84a from './projects'
/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
export const status = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

status.definition = {
    methods: ["get","head"],
    url: '/api/status',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
status.url = (options?: RouteQueryOptions) => {
    return status.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
status.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: status.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::status
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:236
* @route '/api/status'
*/
status.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: status.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
export const sites = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

sites.definition = {
    methods: ["get","head"],
    url: '/api/sites',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
sites.url = (options?: RouteQueryOptions) => {
    return sites.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
sites.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: sites.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::sites
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/sites'
*/
sites.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: sites.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
export const config = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

config.definition = {
    methods: ["get","head"],
    url: '/api/config',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
config.url = (options?: RouteQueryOptions) => {
    return config.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
config.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: config.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::config
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:696
* @route '/api/config'
*/
config.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: config.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
export const worktrees = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: worktrees.url(options),
    method: 'get',
})

worktrees.definition = {
    methods: ["get","head"],
    url: '/api/worktrees',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
worktrees.url = (options?: RouteQueryOptions) => {
    return worktrees.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
worktrees.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: worktrees.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::worktrees
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:825
* @route '/api/worktrees'
*/
worktrees.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: worktrees.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
export const projects = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(options),
    method: 'get',
})

projects.definition = {
    methods: ["get","head"],
    url: '/api/projects',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
projects.url = (options?: RouteQueryOptions) => {
    return projects.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
projects.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: projects.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::projects
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:289
* @route '/api/projects'
*/
projects.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: projects.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
export const workspaces = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces.url(options),
    method: 'get',
})

workspaces.definition = {
    methods: ["get","head"],
    url: '/api/workspaces',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
workspaces.url = (options?: RouteQueryOptions) => {
    return workspaces.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
workspaces.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: workspaces.url(options),
    method: 'get',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::workspaces
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:1354
* @route '/api/workspaces'
*/
workspaces.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: workspaces.url(options),
    method: 'head',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/start'
*/
export const start = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/start'
*/
start.url = (options?: RouteQueryOptions) => {
    return start.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::start
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:517
* @route '/api/start'
*/
start.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/stop'
*/
export const stop = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(options),
    method: 'post',
})

stop.definition = {
    methods: ["post"],
    url: '/api/stop',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/stop'
*/
stop.url = (options?: RouteQueryOptions) => {
    return stop.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::stop
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:525
* @route '/api/stop'
*/
stop.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: stop.url(options),
    method: 'post',
})

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/restart'
*/
export const restart = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(options),
    method: 'post',
})

restart.definition = {
    methods: ["post"],
    url: '/api/restart',
} satisfies RouteDefinition<["post"]>

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/restart'
*/
restart.url = (options?: RouteQueryOptions) => {
    return restart.definition.url + queryParams(options)
}

/**
* @see \HardImpact\Orbit\Http\Controllers\EnvironmentController::restart
* @see vendor/hardimpactdev/orbit-core/src/Http/Controllers/EnvironmentController.php:533
* @route '/api/restart'
*/
restart.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: restart.url(options),
    method: 'post',
})

const api = {
    environments: Object.assign(environments, environments),
    status: Object.assign(status, status),
    sites: Object.assign(sites, sitesE38ead),
    config: Object.assign(config, config),
    worktrees: Object.assign(worktrees, worktrees),
    projects: Object.assign(projects, projects46b84a),
    workspaces: Object.assign(workspaces, workspaces),
    start: Object.assign(start, start),
    stop: Object.assign(stop, stop),
    restart: Object.assign(restart, restart),
}

export default api