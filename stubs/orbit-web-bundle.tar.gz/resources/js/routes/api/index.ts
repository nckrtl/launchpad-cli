import environments from './environments'

const api = {
    environments: Object.assign(environments, environments),
}

export default api