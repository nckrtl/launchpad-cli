<?php

use HardImpact\Waymaker\Facades\Waymaker;

Waymaker::routes();
