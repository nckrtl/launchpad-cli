# Middleware Directory

HTTP middleware for request/response handling.

## Requirements

- Single responsibility per middleware
- Register in `bootstrap/app.php`
- Use for authentication, authorization, request modification
